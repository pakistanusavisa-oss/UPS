<?php
require_once 'includes/config.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = 'All fields are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="background: linear-gradient(135deg, var(--ups-brown) 0%, var(--ups-dark-brown) 100%); color: white; padding: 60px 0; text-align: center;">
        <div class="container">
            <h1 style="font-size: 3rem; margin-bottom: 15px;">Contact Us</h1>
            <p style="font-size: 1.2rem; opacity: 0.9;">We're here to help with all your shipping needs</p>
        </div>
    </section>

    <section style="padding: 80px 0;">
        <div class="container">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: start;">
                <div>
                    <h2 style="color: var(--ups-brown); font-size: 2rem; margin-bottom: 30px;">Get in Touch</h2>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <strong>Thank you!</strong> Your message has been sent successfully. We'll get back to you within 24 hours.
                        </div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-error">
                            <strong>Error:</strong> <?php echo $error; ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="name" required>
                        </div>

                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="email" required>
                        </div>

                        <div class="form-group">
                            <label>Subject</label>
                            <select name="subject" required>
                                <option value="">Select a subject</option>
                                <option value="shipping_inquiry">Shipping Inquiry</option>
                                <option value="tracking_issue">Tracking Issue</option>
                                <option value="billing">Billing Question</option>
                                <option value="complaint">Complaint</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Message</label>
                            <textarea name="message" rows="6" required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>

                <div>
                    <div style="background-color: var(--light-gray); padding: 40px; border-radius: 8px; margin-bottom: 30px;">
                        <h3 style="color: var(--ups-brown); margin-bottom: 25px; font-size: 1.5rem;">Contact Information</h3>

                        <div style="margin-bottom: 25px;">
                            <div style="display: flex; align-items: start; gap: 15px;">
                                <span style="font-size: 1.5rem;">📞</span>
                                <div>
                                    <strong style="color: var(--ups-brown); display: block; margin-bottom: 5px;">Phone</strong>
                                    <p>1-800-PICK-UPS (1-800-742-5877)</p>
                                    <p style="font-size: 0.9rem; color: var(--dark-gray);">Monday - Friday: 8am - 8pm EST</p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-bottom: 25px;">
                            <div style="display: flex; align-items: start; gap: 15px;">
                                <span style="font-size: 1.5rem;">📧</span>
                                <div>
                                    <strong style="color: var(--ups-brown); display: block; margin-bottom: 5px;">Email</strong>
                                    <p>support@upslogistics.com</p>
                                    <p style="font-size: 0.9rem; color: var(--dark-gray);">We respond within 24 hours</p>
                                </div>
                            </div>
                        </div>

                        <div style="margin-bottom: 25px;">
                            <div style="display: flex; align-items: start; gap: 15px;">
                                <span style="font-size: 1.5rem;">📍</span>
                                <div>
                                    <strong style="color: var(--ups-brown); display: block; margin-bottom: 5px;">Headquarters</strong>
                                    <p>55 Glenlake Parkway, NE<br>Atlanta, GA 30328<br>United States</p>
                                </div>
                            </div>
                        </div>

                        <div>
                            <div style="display: flex; align-items: start; gap: 15px;">
                                <span style="font-size: 1.5rem;">⏰</span>
                                <div>
                                    <strong style="color: var(--ups-brown); display: block; margin-bottom: 5px;">Business Hours</strong>
                                    <p>Monday - Friday: 8:00 AM - 8:00 PM EST<br>
                                    Saturday: 9:00 AM - 5:00 PM EST<br>
                                    Sunday: Closed</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="background-color: var(--ups-gold); padding: 30px; border-radius: 8px; text-align: center;">
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">Need Immediate Help?</h3>
                        <p style="color: var(--ups-brown); margin-bottom: 20px;">Track your package or access your account for instant support.</p>
                        <div style="display: flex; gap: 10px; justify-content: center;">
                            <a href="/tracking.php" class="btn btn-primary" style="background: var(--ups-brown); color: white;">Track Package</a>
                            <a href="/login.php" class="btn btn-secondary" style="border-color: var(--ups-brown); color: var(--ups-brown);">Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
