<?php
require_once 'includes/config.php';

if (isLoggedIn()) {
    header('Location: /' . $_SESSION['user_type'] . '/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                $error = 'Your account is currently inactive. Please contact support.';
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_email'] = $user['email'];

                header('Location: /' . $user['user_type'] . '/dashboard.php');
                exit;
            }
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="padding: 80px 0; background-color: var(--light-gray); min-height: 80vh;">
        <div class="container">
            <div class="card" style="max-width: 500px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="color: var(--ups-brown); font-size: 2.5rem; margin-bottom: 10px;">Welcome Back</h1>
                    <p style="color: var(--dark-gray);">Login to access your UPS Logistics account</p>
                </div>

                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>Email Address</label>
                        <input
                            type="email"
                            name="email"
                            placeholder="your.email@example.com"
                            value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            name="password"
                            placeholder="Enter your password"
                            required
                        >
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">
                        Login to Account
                    </button>
                </form>

                <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid var(--medium-gray); text-align: center;">
                    <p style="color: var(--dark-gray);">
                        Don't have an account?
                        <a href="/register.php" style="color: var(--ups-gold); font-weight: 600;">Register Now</a>
                    </p>
                </div>

                <div style="margin-top: 30px; padding: 20px; background-color: #fffbf0; border-radius: 6px; border-left: 4px solid var(--ups-gold);">
                    <strong style="color: var(--ups-brown); display: block; margin-bottom: 10px;">Demo Accounts:</strong>
                    <p style="font-size: 0.9rem; color: var(--text-dark); margin-bottom: 5px;">
                        <strong>Admin:</strong> admin@upslogistics.com / admin123
                    </p>
                    <p style="font-size: 0.9rem; color: var(--text-dark); margin-bottom: 5px;">
                        <strong>Agent:</strong> agent@upslogistics.com / admin123
                    </p>
                    <p style="font-size: 0.9rem; color: var(--text-dark);">
                        <strong>Customer:</strong> customer@example.com / admin123
                    </p>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
