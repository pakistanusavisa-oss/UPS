<?php
require_once 'includes/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UPS Logistics - Global Shipping & Package Delivery</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="top-bar">
            <div class="container">
                <div>
                    <span>📞 1-800-PICK-UPS</span>
                    <span style="margin-left: 20px;">📧 support@upslogistics.com</span>
                </div>
                <div>
                    <?php if (isLoggedIn()): ?>
                        <a href="/<?php echo $_SESSION['user_type']; ?>/dashboard.php">Dashboard</a>
                        <a href="/logout.php">Logout</a>
                    <?php else: ?>
                        <a href="/login.php">Login</a>
                        <a href="/register.php">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="main-header">
            <div class="container">
                <a href="/" class="logo">
                    <span class="logo-shield">UPS</span>
                    <span>Logistics</span>
                </a>
                <nav>
                    <ul>
                        <li><a href="/" class="active">Home</a></li>
                        <li><a href="/tracking.php">Tracking</a></li>
                        <li><a href="/services.php">Services</a></li>
                        <li><a href="/about.php">About</a></li>
                        <li><a href="/contact.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Moving at the Speed of Business</h1>
                <p>Global shipping solutions that deliver excellence across every mile. Track, ship, and manage your logistics with confidence.</p>
                <div style="display: flex; gap: 15px; margin-top: 30px;">
                    <a href="/register.php" class="btn btn-primary">Get Started</a>
                    <a href="/services.php" class="btn btn-secondary">Our Services</a>
                </div>
            </div>

            <div class="tracking-box">
                <h2>Track Your Package</h2>
                <form action="tracking.php" method="GET" class="tracking-form">
                    <input
                        type="text"
                        name="tracking"
                        placeholder="Enter tracking number (e.g., 1Z...)"
                        required
                    >
                    <button type="submit" class="btn btn-primary">Track</button>
                </form>
            </div>
        </div>
    </section>

    <section class="services-section">
        <div class="container">
            <h2 class="section-title">Our Shipping Services</h2>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">📦</div>
                    <h3>Express Shipping</h3>
                    <p>Next-day and time-definite delivery for urgent shipments. Get your packages delivered when time matters most.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">🚚</div>
                    <h3>Ground Shipping</h3>
                    <p>Cost-effective delivery for less urgent shipments. Reliable service at competitive rates.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">✈️</div>
                    <h3>International</h3>
                    <p>Ship to over 220 countries and territories. Customs clearance and door-to-door delivery worldwide.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">📄</div>
                    <h3>Freight Services</h3>
                    <p>Less-than-truckload and full-truckload freight solutions for heavy or large shipments.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">⚡</div>
                    <h3>Same-Day Delivery</h3>
                    <p>Ultra-fast delivery within hours for critical shipments. Available in major metropolitan areas.</p>
                </div>
                <div class="service-card">
                    <div class="service-icon">🏠</div>
                    <h3>Pickup Services</h3>
                    <p>Convenient pickup at your location. Schedule daily pickups or on-demand pickup requests.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="features-section">
        <div class="container">
            <h2 class="section-title">Why Choose UPS Logistics</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🌍</div>
                    <h3>Global Network</h3>
                    <p>Access to the world's largest package delivery network with service to 220+ countries.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3>Real-Time Tracking</h3>
                    <p>Track your shipments in real-time with detailed status updates at every step of the journey.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3>Secure Delivery</h3>
                    <p>Advanced security measures and insurance options to protect your valuable shipments.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💼</div>
                    <h3>Business Solutions</h3>
                    <p>Customized logistics solutions for businesses of all sizes with volume discounts.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Ready to Ship with Confidence?</h2>
            <p>Join thousands of satisfied customers who trust UPS Logistics for their shipping needs.</p>
            <a href="/register.php" class="btn btn-primary" style="background: var(--ups-brown); color: var(--white); font-size: 1.1rem; padding: 15px 40px;">Create Free Account</a>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="/tracking.php">Track Package</a></li>
                        <li><a href="/services.php">Shipping Services</a></li>
                        <li><a href="/login.php">Customer Login</a></li>
                        <li><a href="/register.php">Create Account</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Support</h3>
                    <ul>
                        <li><a href="/contact.php">Contact Us</a></li>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Shipping Rates</a></li>
                        <li><a href="#">FAQs</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Company</h3>
                    <ul>
                        <li><a href="/about.php">About UPS</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Investor Relations</a></li>
                        <li><a href="#">Sustainability</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Connect With Us</h3>
                    <ul>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">LinkedIn</a></li>
                        <li><a href="#">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 UPS Logistics. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </footer>
</body>
</html>
