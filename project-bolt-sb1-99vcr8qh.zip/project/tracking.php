<?php
require_once 'includes/config.php';

$tracking_number = isset($_GET['tracking']) ? sanitize($_GET['tracking']) : '';
$shipment = null;
$tracking_history = [];

if ($tracking_number) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM shipments WHERE tracking_number = ?");
    $stmt->execute([$tracking_number]);
    $shipment = $stmt->fetch();

    if ($shipment) {
        $stmt = $db->prepare("SELECT * FROM tracking_history WHERE shipment_id = ? ORDER BY timestamp DESC");
        $stmt->execute([$shipment['id']]);
        $tracking_history = $stmt->fetchAll();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Package - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="padding: 60px 0; min-height: 70vh;">
        <div class="container">
            <div class="card" style="max-width: 800px; margin: 0 auto;">
                <div class="card-header">
                    <h2>Track Your Package</h2>
                </div>

                <form method="GET" style="margin-bottom: 30px;">
                    <div class="tracking-form">
                        <input
                            type="text"
                            name="tracking"
                            placeholder="Enter tracking number"
                            value="<?php echo htmlspecialchars($tracking_number); ?>"
                            required
                        >
                        <button type="submit" class="btn btn-primary">Track</button>
                    </div>
                </form>

                <?php if ($tracking_number && !$shipment): ?>
                    <div class="alert alert-error">
                        <strong>Not Found:</strong> No shipment found with tracking number "<?php echo htmlspecialchars($tracking_number); ?>"
                    </div>
                <?php elseif ($shipment): ?>
                    <div style="border: 2px solid var(--ups-gold); border-radius: 8px; padding: 30px; margin-bottom: 30px; background-color: #fffbf0;">
                        <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">
                            <div>
                                <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Tracking Number</h3>
                                <p style="font-size: 1.3rem; font-weight: bold; color: var(--ups-brown);"><?php echo htmlspecialchars($shipment['tracking_number']); ?></p>
                            </div>
                            <span class="badge <?php
                                echo match($shipment['status']) {
                                    'delivered' => 'badge-success',
                                    'in_transit' => 'badge-info',
                                    'out_for_delivery' => 'badge-warning',
                                    default => 'badge-secondary'
                                };
                            ?>" style="font-size: 1rem; padding: 8px 16px;">
                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                            </span>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-top: 20px;">
                            <div>
                                <strong style="color: var(--dark-gray);">Service Type:</strong>
                                <p><?php echo htmlspecialchars($shipment['service_type']); ?></p>
                            </div>
                            <div>
                                <strong style="color: var(--dark-gray);">Estimated Delivery:</strong>
                                <p><?php echo $shipment['estimated_delivery'] ? date('M d, Y', strtotime($shipment['estimated_delivery'])) : 'TBD'; ?></p>
                            </div>
                            <div>
                                <strong style="color: var(--dark-gray);">Current Location:</strong>
                                <p><?php echo htmlspecialchars($shipment['current_location'] ?? 'Processing'); ?></p>
                            </div>
                            <div>
                                <strong style="color: var(--dark-gray);">Weight:</strong>
                                <p><?php echo $shipment['package_weight'] ? $shipment['package_weight'] . ' lbs' : 'N/A'; ?></p>
                            </div>
                        </div>
                    </div>

                    <div style="margin-bottom: 30px;">
                        <h3 style="color: var(--ups-brown); margin-bottom: 20px;">Shipment Details</h3>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                            <div style="background-color: var(--light-gray); padding: 20px; border-radius: 6px;">
                                <h4 style="color: var(--ups-brown); margin-bottom: 15px;">📍 From</h4>
                                <p><strong><?php echo htmlspecialchars($shipment['sender_name']); ?></strong></p>
                                <p><?php echo htmlspecialchars($shipment['sender_address']); ?></p>
                                <p><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state'] . ' ' . $shipment['sender_zip']); ?></p>
                                <p><?php echo htmlspecialchars($shipment['sender_country']); ?></p>
                            </div>
                            <div style="background-color: var(--light-gray); padding: 20px; border-radius: 6px;">
                                <h4 style="color: var(--ups-brown); margin-bottom: 15px;">📍 To</h4>
                                <p><strong><?php echo htmlspecialchars($shipment['recipient_name']); ?></strong></p>
                                <p><?php echo htmlspecialchars($shipment['recipient_address']); ?></p>
                                <p><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state'] . ' ' . $shipment['recipient_zip']); ?></p>
                                <p><?php echo htmlspecialchars($shipment['recipient_country']); ?></p>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($tracking_history)): ?>
                        <div>
                            <h3 style="color: var(--ups-brown); margin-bottom: 20px;">📦 Tracking History</h3>
                            <div style="border-left: 3px solid var(--ups-gold); padding-left: 30px;">
                                <?php foreach ($tracking_history as $index => $history): ?>
                                    <div style="position: relative; margin-bottom: 30px;">
                                        <div style="position: absolute; left: -38px; top: 0; width: 16px; height: 16px; background-color: var(--ups-gold); border-radius: 50%; border: 3px solid white;"></div>
                                        <div style="background-color: var(--light-gray); padding: 15px 20px; border-radius: 6px;">
                                            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                                                <strong style="color: var(--ups-brown);"><?php echo htmlspecialchars($history['status']); ?></strong>
                                                <span style="color: var(--dark-gray); font-size: 0.9rem;"><?php echo date('M d, Y g:i A', strtotime($history['timestamp'])); ?></span>
                                            </div>
                                            <?php if ($history['location']): ?>
                                                <p style="color: var(--dark-gray); margin-bottom: 5px;">📍 <?php echo htmlspecialchars($history['location']); ?></p>
                                            <?php endif; ?>
                                            <?php if ($history['description']): ?>
                                                <p style="color: var(--text-dark);"><?php echo htmlspecialchars($history['description']); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
