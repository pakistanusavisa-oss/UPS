# UPS Logistics Management System

A comprehensive logistics and package delivery management system built with PHP, CSS, and HTML. This system mimics the UPS logistics platform with full functionality for managing shipments, tracking packages, and handling users.

## Features

### Public Website
- **Homepage** with tracking functionality
- **Package Tracking** with detailed status updates
- **Services Page** showcasing shipping options
- **About Us** and **Contact** pages
- User authentication (Login/Register)

### Admin Dashboard
- Complete user management (Add, Edit, Delete, Suspend)
- Shipment management and status updates
- Comprehensive reports and analytics
- View all system statistics
- Manage customer, agent, and admin accounts

### Customer Dashboard
- Create new shipments
- Track all personal shipments
- View shipment history
- Update profile information
- Real-time tracking status

### Agent Dashboard
- View pending shipments
- Claim shipments for delivery
- Update shipment status and location
- Track delivery progress
- Manage assigned deliveries

## Technology Stack

- **Backend**: PHP 7.4+
- **Database**: SQLite
- **Frontend**: HTML5, CSS3, JavaScript
- **Design**: UPS-inspired brown and gold color scheme

## Installation

### Requirements
- PHP 7.4 or higher
- SQLite support enabled in PHP
- Apache/Nginx web server or PHP built-in server

### Setup Instructions

1. Clone or download the project files

2. Navigate to the project directory:
   ```bash
   cd /path/to/project
   ```

3. The database will be automatically created on first run at:
   ```
   database/logistics.db
   ```

4. Start the PHP built-in server:
   ```bash
   php -S localhost:8000
   ```

5. Open your browser and visit:
   ```
   http://localhost:8000
   ```

## Default Login Credentials

### Admin Account
- **Email**: admin@upslogistics.com
- **Password**: admin123

### Agent Account
- **Email**: agent@upslogistics.com
- **Password**: admin123

### Customer Account
- **Email**: customer@example.com
- **Password**: admin123

## Project Structure

```
project/
├── admin/                  # Admin dashboard pages
│   ├── dashboard.php
│   ├── users.php
│   ├── shipments.php
│   ├── reports.php
│   └── sidebar.php
├── agent/                  # Agent dashboard pages
│   ├── dashboard.php
│   ├── pending.php
│   ├── my-shipments.php
│   ├── update-shipment.php
│   └── sidebar.php
├── customer/              # Customer dashboard pages
│   ├── dashboard.php
│   ├── create-shipment.php
│   ├── shipments.php
│   ├── profile.php
│   └── sidebar.php
├── database/              # Database files
│   ├── setup.sql
│   └── logistics.db       # Auto-generated
├── includes/              # Shared PHP files
│   ├── config.php         # Configuration & functions
│   ├── header.php
│   └── footer.php
├── css/                   # Stylesheets
│   └── style.css
├── index.php              # Homepage
├── tracking.php           # Package tracking
├── services.php           # Services page
├── about.php              # About page
├── contact.php            # Contact page
├── login.php              # Login page
├── register.php           # Registration page
├── logout.php             # Logout handler
├── .htaccess             # Apache rewrite rules
└── README.md             # This file
```

## Database Schema

### Users Table
Stores all user accounts (admin, agent, customer)

### Shipments Table
Contains all package/shipment information

### Tracking History Table
Stores tracking updates and status changes

### Quotes Table
Saves shipping quote requests

### Support Tickets Table
Customer support ticket system

## Key Features Explained

### Shipment Tracking
- Unique tracking numbers generated for each shipment
- Real-time status updates
- Complete tracking history
- Location tracking at each stage

### User Roles
1. **Admin**: Full system access, user management, reports
2. **Agent**: Claim and process shipments, update delivery status
3. **Customer**: Create shipments, track packages, manage profile

### Service Types
- UPS Express Plus ($89.99) - Next day by 8:30 AM
- UPS Next Day Air ($69.99) - Next business day
- UPS 2nd Day Air ($39.99) - Two business days
- UPS Ground ($19.99) - 1-5 business days
- International Express ($129.99) - 1-3 days worldwide

## Security Features

- Password hashing using PHP's password_hash()
- SQL injection prevention using prepared statements
- XSS protection through input sanitization
- Session-based authentication
- Role-based access control

## Customization

### Changing Colors
Edit `css/style.css` and modify the CSS variables:
```css
:root {
    --ups-brown: #351c15;
    --ups-gold: #ffb500;
    /* Add more custom colors */
}
```

### Adding New Service Types
Update the service costs in `customer/create-shipment.php`

### Email Notifications
Add SMTP configuration in `includes/config.php` to enable email notifications

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This is a demonstration project for educational purposes.

## Support

For issues or questions, please contact the development team.

## Credits

Designed and developed as a comprehensive logistics management solution inspired by UPS.
