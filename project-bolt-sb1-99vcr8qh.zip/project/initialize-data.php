<?php
require_once 'includes/config.php';

$db = getDB();

echo "Initializing sample shipment data...\n\n";

$sample_shipments = [
    [
        'tracking_number' => '1Z999AA10123456784',
        'customer_id' => 3,
        'agent_id' => 2,
        'sender_name' => 'Jane Customer',
        'sender_phone' => '+1234567892',
        'sender_address' => '456 Customer Ave',
        'sender_city' => 'Los Angeles',
        'sender_state' => 'CA',
        'sender_zip' => '90001',
        'sender_country' => 'USA',
        'recipient_name' => 'Bob Wilson',
        'recipient_phone' => '+1987654321',
        'recipient_address' => '789 Delivery Street',
        'recipient_city' => 'New York',
        'recipient_state' => 'NY',
        'recipient_zip' => '10001',
        'recipient_country' => 'USA',
        'package_weight' => 5.5,
        'package_dimensions' => '12 x 10 x 8',
        'package_description' => 'Electronics',
        'service_type' => 'UPS Ground',
        'shipping_cost' => 19.99,
        'status' => 'in_transit',
        'current_location' => 'Chicago Distribution Center',
        'estimated_delivery' => date('Y-m-d', strtotime('+2 days')),
        'created_at' => date('Y-m-d H:i:s', strtotime('-3 days')),
        'updated_at' => date('Y-m-d H:i:s')
    ],
    [
        'tracking_number' => '1Z999AA10123456785',
        'customer_id' => 3,
        'agent_id' => 2,
        'sender_name' => 'Jane Customer',
        'sender_phone' => '+1234567892',
        'sender_address' => '456 Customer Ave',
        'sender_city' => 'Los Angeles',
        'sender_state' => 'CA',
        'sender_zip' => '90001',
        'sender_country' => 'USA',
        'recipient_name' => 'Alice Smith',
        'recipient_phone' => '+1234567890',
        'recipient_address' => '321 Main Street',
        'recipient_city' => 'Miami',
        'recipient_state' => 'FL',
        'recipient_zip' => '33101',
        'recipient_country' => 'USA',
        'package_weight' => 2.5,
        'package_dimensions' => '10 x 8 x 6',
        'package_description' => 'Documents',
        'service_type' => 'UPS Next Day Air',
        'shipping_cost' => 69.99,
        'status' => 'delivered',
        'current_location' => 'Miami',
        'estimated_delivery' => date('Y-m-d', strtotime('-1 day')),
        'actual_delivery' => date('Y-m-d H:i:s', strtotime('-1 day')),
        'created_at' => date('Y-m-d H:i:s', strtotime('-2 days')),
        'updated_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
    ]
];

$shipment_ids = [];
foreach ($sample_shipments as $shipment) {
    $shipment_ids[] = $db->insertRow('shipments', $shipment);
    echo "✓ Created shipment: {$shipment['tracking_number']}\n";
}

$tracking_histories = [
    [
        'shipment_id' => $shipment_ids[0],
        'status' => 'Label Created',
        'location' => 'Los Angeles, CA',
        'description' => 'Shipping label has been created',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-3 days'))
    ],
    [
        'shipment_id' => $shipment_ids[0],
        'status' => 'Picked Up',
        'location' => 'Los Angeles, CA',
        'description' => 'Package picked up by UPS driver',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-3 days 4 hours'))
    ],
    [
        'shipment_id' => $shipment_ids[0],
        'status' => 'In Transit',
        'location' => 'Phoenix Distribution Center',
        'description' => 'Package arrived at facility',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-2 days'))
    ],
    [
        'shipment_id' => $shipment_ids[0],
        'status' => 'In Transit',
        'location' => 'Chicago Distribution Center',
        'description' => 'Package in transit',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-1 day'))
    ],
    [
        'shipment_id' => $shipment_ids[1],
        'status' => 'Label Created',
        'location' => 'Los Angeles, CA',
        'description' => 'Shipping label created',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-2 days'))
    ],
    [
        'shipment_id' => $shipment_ids[1],
        'status' => 'Picked Up',
        'location' => 'Los Angeles, CA',
        'description' => 'Package picked up',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-2 days 2 hours'))
    ],
    [
        'shipment_id' => $shipment_ids[1],
        'status' => 'Out for Delivery',
        'location' => 'Miami, FL',
        'description' => 'Out for delivery',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-1 day 8 hours'))
    ],
    [
        'shipment_id' => $shipment_ids[1],
        'status' => 'Delivered',
        'location' => 'Miami, FL',
        'description' => 'Package delivered successfully',
        'timestamp' => date('Y-m-d H:i:s', strtotime('-1 day'))
    ]
];

foreach ($tracking_histories as $history) {
    $db->insertRow('tracking_history', $history);
}

echo "\n✓ Sample data initialized successfully!\n";
echo "\nYou can now test the tracking system with these tracking numbers:\n";
echo "- 1Z999AA10123456784 (In Transit)\n";
echo "- 1Z999AA10123456785 (Delivered)\n";
?>
