<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="padding: 100px 0; text-align: center; min-height: 60vh;">
        <div class="container">
            <div style="font-size: 8rem; color: var(--ups-gold); margin-bottom: 20px;">📦</div>
            <h1 style="color: var(--ups-brown); font-size: 3rem; margin-bottom: 20px;">404 - Page Not Found</h1>
            <p style="font-size: 1.2rem; color: var(--dark-gray); margin-bottom: 30px;">
                Oops! The page you're looking for seems to have been shipped to the wrong address.
            </p>
            <a href="/" class="btn btn-primary">Return to Homepage</a>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
