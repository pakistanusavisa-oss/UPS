<?php
require_once '../includes/config.php';
checkUserType(['admin']);

$db = getDB();

$total_revenue = $db->query("SELECT SUM(shipping_cost) as total FROM shipments")->fetch()['total'] ?? 0;
$monthly_shipments = $db->query("SELECT COUNT(*) as count FROM shipments WHERE strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')")->fetch()['count'];
$total_customers = $db->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'customer'")->fetch()['count'];
$total_agents = $db->query("SELECT COUNT(*) as count FROM users WHERE user_type = 'agent'")->fetch()['count'];

$shipments_by_status = $db->query("
    SELECT status, COUNT(*) as count
    FROM shipments
    GROUP BY status
")->fetchAll();

$top_customers = $db->query("
    SELECT u.full_name, u.email, COUNT(s.id) as shipment_count, SUM(s.shipping_cost) as total_spent
    FROM users u
    LEFT JOIN shipments s ON u.id = s.customer_id
    WHERE u.user_type = 'customer'
    GROUP BY u.id
    ORDER BY shipment_count DESC
    LIMIT 10
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Admin Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Reports & Analytics</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-value"><?php echo formatCurrency($total_revenue); ?></div>
                    <div class="stat-label">Total Revenue</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-value"><?php echo $monthly_shipments; ?></div>
                    <div class="stat-label">This Month's Shipments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo $total_customers; ?></div>
                    <div class="stat-label">Total Customers</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">🚚</div>
                    <div class="stat-value"><?php echo $total_agents; ?></div>
                    <div class="stat-label">Active Agents</div>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                <div class="card">
                    <div class="card-header">
                        <h2>Shipments by Status</h2>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Status</th>
                                <th>Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($shipments_by_status as $stat): ?>
                                <tr>
                                    <td>
                                        <span class="badge <?php
                                            echo match($stat['status']) {
                                                'delivered' => 'badge-success',
                                                'in_transit' => 'badge-info',
                                                'out_for_delivery' => 'badge-warning',
                                                'pending' => 'badge-secondary',
                                                default => 'badge-secondary'
                                            };
                                        ?>">
                                            <?php echo strtoupper(str_replace('_', ' ', $stat['status'])); ?>
                                        </span>
                                    </td>
                                    <td><strong><?php echo $stat['count']; ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2>Top Customers</h2>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Customer</th>
                                <th>Shipments</th>
                                <th>Total Spent</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_customers as $customer): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($customer['full_name']); ?></strong><br>
                                        <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($customer['email']); ?></small>
                                    </td>
                                    <td><?php echo $customer['shipment_count']; ?></td>
                                    <td><strong><?php echo formatCurrency($customer['total_spent'] ?? 0); ?></strong></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
