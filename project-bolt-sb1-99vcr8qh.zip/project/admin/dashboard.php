<?php
require_once '../includes/config.php';
checkUserType(['admin']);

$db = getDB();

$total_users = $db->query("SELECT COUNT(*) as count FROM users")->fetch()['count'];
$total_shipments = $db->query("SELECT COUNT(*) as count FROM shipments")->fetch()['count'];
$pending_shipments = $db->query("SELECT COUNT(*) as count FROM shipments WHERE status = 'pending'")->fetch()['count'];
$delivered_shipments = $db->query("SELECT COUNT(*) as count FROM shipments WHERE status = 'delivered'")->fetch()['count'];

$recent_shipments = $db->query("
    SELECT s.*, u.full_name as customer_name
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    ORDER BY s.created_at DESC
    LIMIT 10
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Admin Dashboard</h1>
                <div>
                    <span style="color: var(--dark-gray);">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-value"><?php echo $total_users; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-value"><?php echo $total_shipments; ?></div>
                    <div class="stat-label">Total Shipments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-value"><?php echo $pending_shipments; ?></div>
                    <div class="stat-label">Pending Shipments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo $delivered_shipments; ?></div>
                    <div class="stat-label">Delivered</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Recent Shipments</h2>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Tracking Number</th>
                                <th>Customer</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_shipments as $shipment): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($shipment['customer_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state']); ?></td>
                                    <td><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state']); ?></td>
                                    <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                    <td>
                                        <span class="badge <?php
                                            echo match($shipment['status']) {
                                                'delivered' => 'badge-success',
                                                'in_transit' => 'badge-info',
                                                'pending' => 'badge-warning',
                                                default => 'badge-secondary'
                                            };
                                        ?>">
                                            <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
