<?php
require_once '../includes/config.php';
checkUserType(['admin']);

$db = getDB();
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $shipment_id = intval($_POST['shipment_id']);

    if ($_POST['action'] === 'update_status') {
        $status = $_POST['status'];
        $location = sanitize($_POST['location']);
        $description = sanitize($_POST['description']);

        $stmt = $db->prepare("UPDATE shipments SET status = ?, current_location = ? WHERE id = ?");
        $stmt->execute([$status, $location, $shipment_id]);

        $stmt = $db->prepare("INSERT INTO tracking_history (shipment_id, status, location, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$shipment_id, $status, $location, $description]);

        $success = 'Shipment updated successfully.';
    } elseif ($_POST['action'] === 'delete') {
        $stmt = $db->prepare("DELETE FROM tracking_history WHERE shipment_id = ?");
        $stmt->execute([$shipment_id]);

        $stmt = $db->prepare("DELETE FROM shipments WHERE id = ?");
        $stmt->execute([$shipment_id]);

        $success = 'Shipment deleted successfully.';
    }
}

$shipments = $db->query("
    SELECT s.*, u.full_name as customer_name, u.email as customer_email
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    ORDER BY s.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Shipments - Admin Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">All Shipments</h1>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h2>Shipment Management (<?php echo count($shipments); ?> total)</h2>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Tracking #</th>
                                <th>Customer</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Cost</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($shipments as $shipment): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                    <td>
                                        <?php echo htmlspecialchars($shipment['customer_name']); ?><br>
                                        <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($shipment['customer_email']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state']); ?></td>
                                    <td><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state']); ?></td>
                                    <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                    <td>
                                        <span class="badge <?php
                                            echo match($shipment['status']) {
                                                'delivered' => 'badge-success',
                                                'in_transit' => 'badge-info',
                                                'out_for_delivery' => 'badge-warning',
                                                'pending' => 'badge-secondary',
                                                default => 'badge-secondary'
                                            };
                                        ?>">
                                            <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo formatCurrency($shipment['shipping_cost']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                    <td>
                                        <button onclick="openUpdateModal(<?php echo htmlspecialchars(json_encode($shipment)); ?>)" class="btn btn-primary" style="padding: 5px 10px; font-size: 0.85rem; margin-bottom: 5px;">Update</button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this shipment?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="shipment_id" value="<?php echo $shipment['id']; ?>">
                                            <button type="submit" class="btn btn-danger" style="padding: 5px 10px; font-size: 0.85rem;">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div id="updateModal" class="modal">
        <div class="modal-content">
            <span class="modal-close" onclick="document.getElementById('updateModal').style.display='none'">&times;</span>
            <h2 style="color: var(--ups-brown); margin-bottom: 25px;">Update Shipment Status</h2>

            <form method="POST">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="shipment_id" id="modal_shipment_id">

                <div class="form-group">
                    <label>Tracking Number</label>
                    <input type="text" id="modal_tracking" readonly style="background-color: var(--light-gray);">
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select name="status" required>
                        <option value="pending">Pending</option>
                        <option value="processing">Processing</option>
                        <option value="in_transit">In Transit</option>
                        <option value="out_for_delivery">Out for Delivery</option>
                        <option value="delivered">Delivered</option>
                        <option value="exception">Exception</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Current Location</label>
                    <input type="text" name="location" placeholder="e.g., New York Distribution Center" required>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="e.g., Package arrived at facility"></textarea>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">Update Shipment</button>
            </form>
        </div>
    </div>

    <script>
        function openUpdateModal(shipment) {
            document.getElementById('modal_shipment_id').value = shipment.id;
            document.getElementById('modal_tracking').value = shipment.tracking_number;
            document.getElementById('updateModal').style.display = 'block';
        }
    </script>
</body>
</html>
