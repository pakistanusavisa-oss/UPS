<?php
require_once 'includes/config.php';

if (isLoggedIn()) {
    header('Location: /' . $_SESSION['user_type'] . '/dashboard.php');
    exit;
}

$error = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = sanitize($_POST['phone'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? '');
    $state = sanitize($_POST['state'] ?? '');
    $zip_code = sanitize($_POST['zip_code'] ?? '');
    $country = sanitize($_POST['country'] ?? '');

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $db = getDB();

        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'An account with this email already exists.';
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $db->prepare("
                INSERT INTO users (email, password, full_name, phone, address, city, state, zip_code, country, user_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'customer')
            ");

            if ($stmt->execute([$email, $hashed_password, $full_name, $phone, $address, $city, $state, $zip_code, $country])) {
                $success = true;
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="padding: 60px 0; background-color: var(--light-gray);">
        <div class="container">
            <div class="card" style="max-width: 700px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="color: var(--ups-brown); font-size: 2.5rem; margin-bottom: 10px;">Create Account</h1>
                    <p style="color: var(--dark-gray);">Join UPS Logistics and start shipping today</p>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <strong>Success!</strong> Your account has been created successfully.
                        <a href="/login.php" style="color: var(--success); text-decoration: underline; font-weight: 600;">Click here to login</a>
                    </div>
                <?php elseif ($error): ?>
                    <div class="alert alert-error">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <form method="POST">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Full Name *</label>
                            <input
                                type="text"
                                name="full_name"
                                value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label>Email Address *</label>
                            <input
                                type="email"
                                name="email"
                                value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>Password *</label>
                            <input
                                type="password"
                                name="password"
                                placeholder="At least 6 characters"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label>Confirm Password *</label>
                            <input
                                type="password"
                                name="confirm_password"
                                required
                            >
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input
                            type="tel"
                            name="phone"
                            value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>"
                            placeholder="+1 (555) 123-4567"
                        >
                    </div>

                    <div class="form-group">
                        <label>Street Address</label>
                        <input
                            type="text"
                            name="address"
                            value="<?php echo htmlspecialchars($_POST['address'] ?? ''); ?>"
                        >
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>City</label>
                            <input
                                type="text"
                                name="city"
                                value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label>State</label>
                            <input
                                type="text"
                                name="state"
                                value="<?php echo htmlspecialchars($_POST['state'] ?? ''); ?>"
                            >
                        </div>

                        <div class="form-group">
                            <label>ZIP Code</label>
                            <input
                                type="text"
                                name="zip_code"
                                value="<?php echo htmlspecialchars($_POST['zip_code'] ?? ''); ?>"
                            >
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Country</label>
                        <select name="country">
                            <option value="USA">United States</option>
                            <option value="Canada">Canada</option>
                            <option value="Mexico">Mexico</option>
                            <option value="UK">United Kingdom</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">
                        Create Account
                    </button>
                </form>

                <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid var(--medium-gray); text-align: center;">
                    <p style="color: var(--dark-gray);">
                        Already have an account?
                        <a href="/login.php" style="color: var(--ups-gold); font-weight: 600;">Login Here</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
