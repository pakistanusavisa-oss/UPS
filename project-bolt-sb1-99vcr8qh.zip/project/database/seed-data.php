<?php
require_once __DIR__ . '/../includes/config.php';

$db = getDB();

echo "Seeding database with sample data...\n\n";

$customer_stmt = $db->prepare("SELECT id FROM users WHERE user_type = 'customer' LIMIT 1");
$customer_stmt->execute();
$customer = $customer_stmt->fetch();

if (!$customer) {
    echo "No customer found. Please register a customer first.\n";
    exit;
}

$customer_id = $customer['id'];

$agent_stmt = $db->prepare("SELECT id FROM users WHERE user_type = 'agent' LIMIT 1");
$agent_stmt->execute();
$agent = $agent_stmt->fetch();
$agent_id = $agent ? $agent['id'] : null;

$sample_shipments = [
    [
        'tracking_number' => '1Z' . strtoupper(bin2hex(random_bytes(8))),
        'sender_name' => 'John Smith',
        'sender_address' => '123 Main Street',
        'sender_city' => 'New York',
        'sender_state' => 'NY',
        'sender_zip' => '10001',
        'recipient_name' => 'Jane Doe',
        'recipient_address' => '456 Oak Avenue',
        'recipient_city' => 'Los Angeles',
        'recipient_state' => 'CA',
        'recipient_zip' => '90001',
        'service_type' => 'UPS Ground',
        'status' => 'in_transit',
        'location' => 'Chicago Distribution Center',
        'weight' => 5.5,
        'cost' => 19.99
    ],
    [
        'tracking_number' => '1Z' . strtoupper(bin2hex(random_bytes(8))),
        'sender_name' => 'Alice Johnson',
        'sender_address' => '789 Pine Road',
        'sender_city' => 'Miami',
        'sender_state' => 'FL',
        'sender_zip' => '33101',
        'recipient_name' => 'Bob Wilson',
        'recipient_address' => '321 Elm Street',
        'recipient_city' => 'Seattle',
        'recipient_state' => 'WA',
        'recipient_zip' => '98101',
        'service_type' => 'UPS Next Day Air',
        'status' => 'out_for_delivery',
        'location' => 'Seattle Local Facility',
        'weight' => 3.2,
        'cost' => 69.99
    ]
];

foreach ($sample_shipments as $shipment) {
    try {
        $stmt = $db->prepare("
            INSERT INTO shipments (
                tracking_number, customer_id, agent_id,
                sender_name, sender_phone, sender_address, sender_city, sender_state, sender_zip, sender_country,
                recipient_name, recipient_phone, recipient_address, recipient_city, recipient_state, recipient_zip, recipient_country,
                package_weight, service_type, shipping_cost, status, current_location, estimated_delivery
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $estimated_delivery = date('Y-m-d', strtotime('+2 days'));

        $stmt->execute([
            $shipment['tracking_number'],
            $customer_id,
            $agent_id,
            $shipment['sender_name'],
            '+1234567890',
            $shipment['sender_address'],
            $shipment['sender_city'],
            $shipment['sender_state'],
            $shipment['sender_zip'],
            'USA',
            $shipment['recipient_name'],
            '+1987654321',
            $shipment['recipient_address'],
            $shipment['recipient_city'],
            $shipment['recipient_state'],
            $shipment['recipient_zip'],
            'USA',
            $shipment['weight'],
            $shipment['service_type'],
            $shipment['cost'],
            $shipment['status'],
            $shipment['location'],
            $estimated_delivery
        ]);

        $shipment_id = $db->lastInsertId();

        $history_stmt = $db->prepare("INSERT INTO tracking_history (shipment_id, status, location, description) VALUES (?, ?, ?, ?)");
        $history_stmt->execute([
            $shipment_id,
            'Label Created',
            $shipment['sender_city'],
            'Shipping label has been created'
        ]);

        $history_stmt->execute([
            $shipment_id,
            'Picked Up',
            $shipment['sender_city'],
            'Package picked up by UPS driver'
        ]);

        if ($shipment['status'] === 'in_transit' || $shipment['status'] === 'out_for_delivery') {
            $history_stmt->execute([
                $shipment_id,
                'In Transit',
                $shipment['location'],
                'Package is in transit to destination'
            ]);
        }

        if ($shipment['status'] === 'out_for_delivery') {
            $history_stmt->execute([
                $shipment_id,
                'Out for Delivery',
                $shipment['recipient_city'],
                'Package is out for delivery'
            ]);
        }

        echo "✓ Created shipment: {$shipment['tracking_number']}\n";
    } catch (Exception $e) {
        echo "✗ Error creating shipment: {$e->getMessage()}\n";
    }
}

echo "\n✓ Database seeded successfully!\n";
?>
