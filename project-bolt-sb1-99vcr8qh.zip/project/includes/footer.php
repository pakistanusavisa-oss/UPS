<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="/tracking.php">Track Package</a></li>
                    <li><a href="/services.php">Shipping Services</a></li>
                    <li><a href="/login.php">Customer Login</a></li>
                    <li><a href="/register.php">Create Account</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Support</h3>
                <ul>
                    <li><a href="/contact.php">Contact Us</a></li>
                    <li><a href="#">Help Center</a></li>
                    <li><a href="#">Shipping Rates</a></li>
                    <li><a href="#">FAQs</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Company</h3>
                <ul>
                    <li><a href="/about.php">About UPS</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">Investor Relations</a></li>
                    <li><a href="#">Sustainability</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Connect With Us</h3>
                <ul>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">LinkedIn</a></li>
                    <li><a href="#">Instagram</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 UPS Logistics. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
        </div>
    </div>
</footer>
