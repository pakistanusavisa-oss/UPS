<?php
// Database configuration
define('DB_PATH', __DIR__ . '/../database/logistics.db');

// Site configuration
define('SITE_NAME', 'UPS Logistics');
define('SITE_URL', 'http://localhost:8000');

// Session configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
require_once __DIR__ . '/mockdb.php';

function getDB() {
    static $db = null;
    if ($db === null) {
        $db = new MockDB();
    }
    return $db;
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_type']);
}

// Check user type
function checkUserType($allowed_types) {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }

    if (!in_array($_SESSION['user_type'], $allowed_types)) {
        header('Location: /index.php');
        exit;
    }
}

// Get current user data
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

// Generate tracking number
function generateTrackingNumber() {
    return '1Z' . strtoupper(bin2hex(random_bytes(8)));
}

// Format currency
function formatCurrency($amount) {
    return '$' . number_format($amount, 2);
}

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Initialize database
$db = getDB();
?>
