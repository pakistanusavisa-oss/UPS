<?php

class JsonDB {
    private $data_dir;

    public function __construct($data_dir) {
        $this->data_dir = $data_dir;
        if (!file_exists($data_dir)) {
            mkdir($data_dir, 0777, true);
        }
    }

    private function getFilePath($table) {
        return $this->data_dir . '/' . $table . '.json';
    }

    private function readTable($table) {
        $file = $this->getFilePath($table);
        if (!file_exists($file)) {
            return [];
        }
        $content = file_get_contents($file);
        return json_decode($content, true) ?: [];
    }

    private function writeTable($table, $data) {
        $file = $this->getFilePath($table);
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    public function query($sql) {
        return new JsonDBStatement($this, $sql);
    }

    public function prepare($sql) {
        return new JsonDBStatement($this, $sql);
    }

    public function lastInsertId() {
        return $this->last_insert_id ?? 0;
    }

    public function exec($sql) {
        return true;
    }

    public function insert($table, $data) {
        $records = $this->readTable($table);
        $data['id'] = count($records) > 0 ? max(array_column($records, 'id')) + 1 : 1;
        $data['created_at'] = $data['created_at'] ?? date('Y-m-d H:i:s');
        $data['updated_at'] = $data['updated_at'] ?? date('Y-m-d H:i:s');
        $records[] = $data;
        $this->writeTable($table, $records);
        $this->last_insert_id = $data['id'];
        return $data['id'];
    }

    public function select($table, $conditions = [], $order = null, $limit = null) {
        $records = $this->readTable($table);

        if (!empty($conditions)) {
            $records = array_filter($records, function($record) use ($conditions) {
                foreach ($conditions as $key => $value) {
                    if (!isset($record[$key]) || $record[$key] != $value) {
                        return false;
                    }
                }
                return true;
            });
        }

        if ($order) {
            usort($records, function($a, $b) use ($order) {
                $field = str_replace(' DESC', '', $order);
                $desc = strpos($order, 'DESC') !== false;
                $result = strcmp($a[$field] ?? '', $b[$field] ?? '');
                return $desc ? -$result : $result;
            });
        }

        if ($limit) {
            $records = array_slice($records, 0, $limit);
        }

        return array_values($records);
    }

    public function update($table, $data, $conditions) {
        $records = $this->readTable($table);
        $updated = false;

        foreach ($records as &$record) {
            $match = true;
            foreach ($conditions as $key => $value) {
                if (!isset($record[$key]) || $record[$key] != $value) {
                    $match = false;
                    break;
                }
            }

            if ($match) {
                foreach ($data as $key => $value) {
                    $record[$key] = $value;
                }
                $record['updated_at'] = date('Y-m-d H:i:s');
                $updated = true;
            }
        }

        if ($updated) {
            $this->writeTable($table, $records);
        }

        return $updated;
    }

    public function delete($table, $conditions) {
        $records = $this->readTable($table);
        $filtered = array_filter($records, function($record) use ($conditions) {
            foreach ($conditions as $key => $value) {
                if (!isset($record[$key]) || $record[$key] != $value) {
                    return true;
                }
            }
            return false;
        });

        $this->writeTable($table, array_values($filtered));
        return count($records) - count($filtered);
    }

    public function count($table, $conditions = []) {
        return count($this->select($table, $conditions));
    }
}

class JsonDBStatement {
    private $db;
    private $sql;
    private $result;

    public function __construct($db, $sql) {
        $this->db = $db;
        $this->sql = $sql;
    }

    public function execute($params = []) {
        $sql = $this->sql;

        foreach ($params as $param) {
            $sql = preg_replace('/\?/', "'" . addslashes($param) . "'", $sql, 1);
        }

        if (preg_match('/SELECT .* FROM (\w+)(.*)/i', $sql, $matches)) {
            $table = $matches[1];
            $this->result = $this->db->select($table);
            return true;
        }

        return true;
    }

    public function fetch() {
        if (is_array($this->result) && count($this->result) > 0) {
            return array_shift($this->result);
        }
        return false;
    }

    public function fetchAll() {
        return is_array($this->result) ? $this->result : [];
    }
}
?>
