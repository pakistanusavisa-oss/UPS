<header>
    <div class="top-bar">
        <div class="container">
            <div>
                <span>📞 1-800-PICK-UPS</span>
                <span style="margin-left: 20px;">📧 support@upslogistics.com</span>
            </div>
            <div>
                <?php if (isLoggedIn()): ?>
                    <a href="/<?php echo $_SESSION['user_type']; ?>/dashboard.php">Dashboard</a>
                    <a href="/logout.php">Logout</a>
                <?php else: ?>
                    <a href="/login.php">Login</a>
                    <a href="/register.php">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="main-header">
        <div class="container">
            <a href="/" class="logo">
                <span class="logo-shield">UPS</span>
                <span>Logistics</span>
            </a>
            <nav>
                <ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/tracking.php">Tracking</a></li>
                    <li><a href="/services.php">Services</a></li>
                    <li><a href="/about.php">About</a></li>
                    <li><a href="/contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </div>
</header>
