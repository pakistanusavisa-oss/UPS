<?php

class MockDB {
    private static $data = null;
    private static $data_file;
    private $last_insert_id = 0;

    public function __construct() {
        self::$data_file = __DIR__ . '/../database/data.json';
        $this->loadData();
    }

    private function loadData() {
        if (self::$data === null) {
            if (file_exists(self::$data_file)) {
                self::$data = json_decode(file_get_contents(self::$data_file), true);
            } else {
                $this->initializeData();
            }
        }
    }

    private function saveData() {
        if (!file_exists(dirname(self::$data_file))) {
            mkdir(dirname(self::$data_file), 0777, true);
        }
        file_put_contents(self::$data_file, json_encode(self::$data, JSON_PRETTY_PRINT));
    }

    private function initializeData() {
        self::$data = [
            'users' => [
                [
                    'id' => 1,
                    'email' => 'admin@upslogistics.com',
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                    'full_name' => 'System Administrator',
                    'phone' => '+1234567890',
                    'address' => '',
                    'city' => '',
                    'state' => '',
                    'zip_code' => '',
                    'country' => '',
                    'user_type' => 'admin',
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 2,
                    'email' => 'agent@upslogistics.com',
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                    'full_name' => 'John Agent',
                    'phone' => '+1234567891',
                    'address' => '123 Agent St',
                    'city' => 'New York',
                    'state' => 'NY',
                    'zip_code' => '10001',
                    'country' => 'USA',
                    'user_type' => 'agent',
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 3,
                    'email' => 'customer@example.com',
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                    'full_name' => 'Jane Customer',
                    'phone' => '+1234567892',
                    'address' => '456 Customer Ave',
                    'city' => 'Los Angeles',
                    'state' => 'CA',
                    'zip_code' => '90001',
                    'country' => 'USA',
                    'user_type' => 'customer',
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ]
            ],
            'shipments' => [],
            'tracking_history' => [],
            'quotes' => [],
            'support_tickets' => [],
            'ticket_responses' => []
        ];
        $this->saveData();
    }

    public function query($sql) {
        return new MockStatement($this, $sql, []);
    }

    public function prepare($sql) {
        return new MockStatement($this, $sql, []);
    }

    public function exec($sql) {
        return true;
    }

    public function lastInsertId() {
        return $this->last_insert_id;
    }

    public function getData($table) {
        $this->loadData();
        return self::$data[$table] ?? [];
    }

    public function setData($table, $data) {
        self::$data[$table] = $data;
        $this->saveData();
    }

    public function insertRow($table, $row) {
        $data = $this->getData($table);
        $row['id'] = count($data) > 0 ? max(array_column($data, 'id')) + 1 : 1;
        $data[] = $row;
        $this->setData($table, $data);
        $this->last_insert_id = $row['id'];
        return $row['id'];
    }

    public function updateRows($table, $updates, $conditions) {
        $data = $this->getData($table);
        foreach ($data as &$row) {
            if ($this->matchConditions($row, $conditions)) {
                foreach ($updates as $key => $value) {
                    $row[$key] = $value;
                }
            }
        }
        $this->setData($table, $data);
    }

    public function deleteRows($table, $conditions) {
        $data = $this->getData($table);
        $data = array_filter($data, function($row) use ($conditions) {
            return !$this->matchConditions($row, $conditions);
        });
        $this->setData($table, array_values($data));
    }

    private function matchConditions($row, $conditions) {
        foreach ($conditions as $key => $value) {
            if (!isset($row[$key]) || $row[$key] != $value) {
                return false;
            }
        }
        return true;
    }
}

class MockStatement {
    private $db;
    private $sql;
    private $params;
    private $result = null;
    private $fetchIndex = 0;

    public function __construct($db, $sql, $params) {
        $this->db = $db;
        $this->sql = $sql;
        $this->params = $params;
    }

    public function execute($params = []) {
        $this->params = $params;
        $sql = $this->sql;

        foreach ($params as $param) {
            $sql = preg_replace('/\?/', is_numeric($param) ? $param : "'" . addslashes($param) . "'", $sql, 1);
        }

        if (preg_match('/SELECT\s+(.*?)\s+FROM\s+(\w+)(.*)/is', $sql, $matches)) {
            $table = $matches[2];
            $data = $this->db->getData($table);

            $where = $matches[3] ?? '';
            if (preg_match('/WHERE\s+(.*?)(\s+ORDER|\s+LIMIT|$)/is', $where, $whereMatches)) {
                $whereClause = $whereMatches[1];
                $data = $this->filterData($data, $whereClause);
            }

            if (preg_match('/LEFT\s+JOIN\s+(\w+)\s+(\w+)\s+ON\s+(\w+)\.(\w+)\s*=\s*(\w+)\.(\w+)/is', $where, $joinMatches)) {
                $joinTable = $joinMatches[1];
                $joinAlias = $joinMatches[2];
                $joinData = $this->db->getData($joinTable);

                $data = array_map(function($row) use ($joinData, $joinMatches, $table) {
                    $leftKey = $joinMatches[4];
                    $rightKey = $joinMatches[6];

                    foreach ($joinData as $joinRow) {
                        if (isset($row[$leftKey]) && isset($joinRow[$rightKey]) && $row[$leftKey] == $joinRow[$rightKey]) {
                            foreach ($joinRow as $key => $value) {
                                if ($key !== 'id') {
                                    $row[$key] = $value;
                                }
                            }
                            break;
                        }
                    }
                    return $row;
                }, $data);
            }

            if (preg_match('/ORDER\s+BY\s+(\w+)\.?(\w+)?\s*(DESC|ASC)?/is', $where, $orderMatches)) {
                $orderField = $orderMatches[2] ?? $orderMatches[1];
                $orderDir = $orderMatches[3] ?? 'ASC';
                usort($data, function($a, $b) use ($orderField, $orderDir) {
                    $result = ($a[$orderField] ?? '') <=> ($b[$orderField] ?? '');
                    return $orderDir === 'DESC' ? -$result : $result;
                });
            }

            if (preg_match('/LIMIT\s+(\d+)/i', $where, $limitMatches)) {
                $data = array_slice($data, 0, (int)$limitMatches[1]);
            }

            if (preg_match('/COUNT\(\*\)\s+as\s+(\w+)/i', $matches[1], $countMatches)) {
                $this->result = [[$countMatches[1] => count($data)]];
            } elseif (preg_match('/SUM\((\w+)\)\s+as\s+(\w+)/i', $matches[1], $sumMatches)) {
                $total = array_sum(array_column($data, $sumMatches[1]));
                $this->result = [[$sumMatches[2] => $total]];
            } else {
                $this->result = array_values($data);
            }

            return true;
        }

        if (preg_match('/INSERT\s+INTO\s+(\w+)\s*\((.*?)\)\s*VALUES\s*\((.*?)\)/is', $sql, $matches)) {
            $table = $matches[1];
            $columns = array_map('trim', explode(',', $matches[2]));
            $values = $this->params;

            $row = array_combine($columns, $values);
            $row['created_at'] = $row['created_at'] ?? date('Y-m-d H:i:s');
            $row['updated_at'] = $row['updated_at'] ?? date('Y-m-d H:i:s');

            $this->db->insertRow($table, $row);
            return true;
        }

        if (preg_match('/UPDATE\s+(\w+)\s+SET\s+(.*?)\s+WHERE\s+(.*)/is', $sql, $matches)) {
            $table = $matches[1];
            $updates = $this->parseUpdates($matches[2]);
            $conditions = $this->parseConditions($matches[3]);
            $this->db->updateRows($table, $updates, $conditions);
            return true;
        }

        if (preg_match('/DELETE\s+FROM\s+(\w+)\s+WHERE\s+(.*)/is', $sql, $matches)) {
            $table = $matches[1];
            $conditions = $this->parseConditions($matches[2]);
            $this->db->deleteRows($table, $conditions);
            return true;
        }

        return true;
    }

    private function filterData($data, $where) {
        return array_filter($data, function($row) use ($where) {
            if (preg_match_all('/(\w+)\s*=\s*[\'"]?(.*?)[\'"]?\s*(AND|OR|$)/i', $where, $matches)) {
                foreach ($matches[1] as $i => $field) {
                    $value = trim($matches[2][$i], "'\"");
                    if (!isset($row[$field]) || $row[$field] != $value) {
                        return false;
                    }
                }
            }
            return true;
        });
    }

    private function parseUpdates($updates) {
        $result = [];
        if (preg_match_all('/(\w+)\s*=\s*\?/i', $updates, $matches)) {
            foreach ($matches[1] as $i => $field) {
                $result[$field] = $this->params[$i] ?? null;
            }
        }
        return $result;
    }

    private function parseConditions($conditions) {
        $result = [];
        $paramIndex = 0;
        if (preg_match_all('/(\w+)\s*=\s*\?/i', $conditions, $matches)) {
            foreach ($matches[1] as $field) {
                if (isset($this->params[$paramIndex])) {
                    $result[$field] = $this->params[$paramIndex++];
                }
            }
        }
        return $result;
    }

    public function fetch() {
        if ($this->result && $this->fetchIndex < count($this->result)) {
            return $this->result[$this->fetchIndex++];
        }
        return false;
    }

    public function fetchAll() {
        return $this->result ?? [];
    }

    public function setAttribute($attr, $value) {}
}
?>
