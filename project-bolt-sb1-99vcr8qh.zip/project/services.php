<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="background: linear-gradient(135deg, var(--ups-brown) 0%, var(--ups-dark-brown) 100%); color: white; padding: 60px 0; text-align: center;">
        <div class="container">
            <h1 style="font-size: 3rem; margin-bottom: 15px;">Shipping Services</h1>
            <p style="font-size: 1.2rem; opacity: 0.9;">Comprehensive logistics solutions for every shipping need</p>
        </div>
    </section>

    <section style="padding: 80px 0;">
        <div class="container">
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">⚡</div>
                    <h3>UPS Express Plus</h3>
                    <p><strong>Next-day delivery by 8:30 AM</strong></p>
                    <p>Critical shipments delivered first thing in the morning. Perfect for time-sensitive business documents and packages.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ Early morning delivery</li>
                        <li>✓ 1-day delivery time</li>
                        <li>✓ Saturday delivery available</li>
                        <li>✓ Money-back guarantee</li>
                    </ul>
                </div>

                <div class="service-card">
                    <div class="service-icon">📦</div>
                    <h3>UPS Next Day Air</h3>
                    <p><strong>Next business day delivery</strong></p>
                    <p>Fast, reliable overnight delivery to businesses and residences. Available with multiple delivery time options.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ Next business day by 10:30 AM</li>
                        <li>✓ Available to all 50 states</li>
                        <li>✓ Signature required</li>
                        <li>✓ Up to $100 insurance included</li>
                    </ul>
                </div>

                <div class="service-card">
                    <div class="service-icon">✈️</div>
                    <h3>UPS 2nd Day Air</h3>
                    <p><strong>Two business days</strong></p>
                    <p>Cost-effective expedited shipping for less urgent deliveries. Perfect balance of speed and economy.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ 2-day delivery by end of day</li>
                        <li>✓ More affordable than overnight</li>
                        <li>✓ Residential delivery available</li>
                        <li>✓ Tracking included</li>
                    </ul>
                </div>

                <div class="service-card">
                    <div class="service-icon">🚚</div>
                    <h3>UPS Ground</h3>
                    <p><strong>1-5 business days</strong></p>
                    <p>Reliable, economical ground delivery for packages that don't require expedited service.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ Day-definite delivery</li>
                        <li>✓ Best value shipping</li>
                        <li>✓ Packages up to 150 lbs</li>
                        <li>✓ Saturday delivery available</li>
                    </ul>
                </div>

                <div class="service-card">
                    <div class="service-icon">🌍</div>
                    <h3>International Express</h3>
                    <p><strong>1-3 days worldwide</strong></p>
                    <p>Fast international shipping to over 220 countries and territories with customs clearance included.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ Worldwide coverage</li>
                        <li>✓ Customs brokerage included</li>
                        <li>✓ Duties & taxes prepaid option</li>
                        <li>✓ Real-time tracking</li>
                    </ul>
                </div>

                <div class="service-card">
                    <div class="service-icon">🏭</div>
                    <h3>Freight Services</h3>
                    <p><strong>For larger shipments</strong></p>
                    <p>LTL and FTL freight services for heavy or oversized shipments requiring pallet delivery.</p>
                    <ul style="text-align: left; margin-top: 15px; color: var(--dark-gray);">
                        <li>✓ Shipments over 150 lbs</li>
                        <li>✓ Lift gate service available</li>
                        <li>✓ Inside delivery options</li>
                        <li>✓ Guaranteed delivery times</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: var(--light-gray); padding: 80px 0;">
        <div class="container">
            <h2 class="section-title">Additional Services</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 40px;">
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">📋 Package Pickup</h3>
                    <p>Schedule pickups at your location. One-time, daily, or weekly pickup options available.</p>
                </div>
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">📦 Pack & Ship</h3>
                    <p>Professional packing services at UPS Store locations. We handle the packing for you.</p>
                </div>
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">🔒 Insurance Coverage</h3>
                    <p>Protect your shipments with additional insurance coverage up to $50,000 per package.</p>
                </div>
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">✍️ Signature Required</h3>
                    <p>Add signature confirmation for secure delivery. Multiple signature options available.</p>
                </div>
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">📱 SMS Notifications</h3>
                    <p>Get real-time delivery updates via text message. Stay informed every step of the way.</p>
                </div>
                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
                    <h3 style="color: var(--ups-brown); margin-bottom: 15px;">🏪 Hold for Pickup</h3>
                    <p>Have packages held at convenient UPS locations for pickup at your convenience.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 80px 0; text-align: center;">
        <div class="container">
            <h2 style="color: var(--ups-brown); font-size: 2.5rem; margin-bottom: 20px;">Ready to Get Started?</h2>
            <p style="font-size: 1.2rem; margin-bottom: 30px; color: var(--dark-gray);">Create an account to access all shipping services and special rates.</p>
            <a href="/register.php" class="btn btn-primary" style="font-size: 1.1rem; padding: 15px 40px;">Create Free Account</a>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
