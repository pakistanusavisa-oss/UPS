<?php
require_once '../includes/config.php';
checkUserType(['agent']);

$db = getDB();
$agent_id = $_SESSION['user_id'];

$assigned_shipments = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE agent_id = ?");
$assigned_shipments->execute([$agent_id]);
$assigned_shipments = $assigned_shipments->fetch()['count'];

$pending_shipments = $db->query("SELECT COUNT(*) as count FROM shipments WHERE status IN ('pending', 'processing')")->fetch()['count'];

$in_transit = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE agent_id = ? AND status = 'in_transit'");
$in_transit->execute([$agent_id]);
$in_transit = $in_transit->fetch()['count'];

$delivered_today = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE agent_id = ? AND status = 'delivered' AND DATE(actual_delivery) = DATE('now')");
$delivered_today->execute([$agent_id]);
$delivered_today = $delivered_today->fetch()['count'];

$recent_shipments = $db->prepare("
    SELECT s.*, u.full_name as customer_name, u.email as customer_email
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    WHERE s.agent_id = ?
    ORDER BY s.updated_at DESC
    LIMIT 10
");
$recent_shipments->execute([$agent_id]);
$recent_shipments = $recent_shipments->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Dashboard - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Agent Dashboard</h1>
                <div>
                    <span style="color: var(--dark-gray);">Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📋</div>
                    <div class="stat-value"><?php echo $assigned_shipments; ?></div>
                    <div class="stat-label">My Shipments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-value"><?php echo $pending_shipments; ?></div>
                    <div class="stat-label">Pending Assignments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">🚚</div>
                    <div class="stat-value"><?php echo $in_transit; ?></div>
                    <div class="stat-label">In Transit</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo $delivered_today; ?></div>
                    <div class="stat-label">Delivered Today</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>My Recent Shipments</h2>
                </div>
                <?php if (empty($recent_shipments)): ?>
                    <div style="text-align: center; padding: 60px 20px; color: var(--dark-gray);">
                        <div style="font-size: 4rem; margin-bottom: 20px;">📦</div>
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">No Assigned Shipments</h3>
                        <p style="margin-bottom: 25px;">Check the pending shipments to claim assignments.</p>
                        <a href="/agent/pending.php" class="btn btn-primary">View Pending Shipments</a>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tracking Number</th>
                                    <th>Customer</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_shipments as $shipment): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['customer_name']); ?><br>
                                            <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($shipment['customer_email']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                        <td>
                                            <span class="badge <?php
                                                echo match($shipment['status']) {
                                                    'delivered' => 'badge-success',
                                                    'in_transit' => 'badge-info',
                                                    'out_for_delivery' => 'badge-warning',
                                                    'pending' => 'badge-secondary',
                                                    default => 'badge-secondary'
                                                };
                                            ?>">
                                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="/agent/update-shipment.php?id=<?php echo $shipment['id']; ?>" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.85rem;">Update</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
