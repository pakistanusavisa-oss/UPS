<div class="dashboard-sidebar">
    <div class="user-info">
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
        </div>
        <h3><?php echo htmlspecialchars($_SESSION['user_name']); ?></h3>
        <p style="opacity: 0.8; font-size: 0.9rem;">Delivery Agent</p>
    </div>

    <nav>
        <ul>
            <li><a href="/agent/dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">📊 Dashboard</a></li>
            <li><a href="/agent/pending.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'pending.php' ? 'active' : ''; ?>">⏳ Pending Shipments</a></li>
            <li><a href="/agent/my-shipments.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'my-shipments.php' ? 'active' : ''; ?>">📦 My Shipments</a></li>
            <li><a href="/" style="border-top: 1px solid rgba(255,255,255,0.1); margin-top: 20px; padding-top: 20px;">🏠 Main Site</a></li>
            <li><a href="/logout.php">🚪 Logout</a></li>
        </ul>
    </nav>
</div>
