<?php
require_once '../includes/config.php';
checkUserType(['agent']);

$db = getDB();
$agent_id = $_SESSION['user_id'];

$shipments = $db->prepare("
    SELECT s.*, u.full_name as customer_name, u.email as customer_email
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    WHERE s.agent_id = ?
    ORDER BY s.updated_at DESC
");
$shipments->execute([$agent_id]);
$shipments = $shipments->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shipments - Agent Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">My Shipments</h1>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Assigned Shipments (<?php echo count($shipments); ?>)</h2>
                </div>
                <?php if (empty($shipments)): ?>
                    <div style="text-align: center; padding: 60px 20px; color: var(--dark-gray);">
                        <div style="font-size: 4rem; margin-bottom: 20px;">📦</div>
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">No Assigned Shipments</h3>
                        <p style="margin-bottom: 25px;">Claim shipments from the pending list to get started.</p>
                        <a href="/agent/pending.php" class="btn btn-primary">View Pending Shipments</a>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tracking #</th>
                                    <th>Customer</th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Est. Delivery</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($shipments as $shipment): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['customer_name']); ?><br>
                                            <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($shipment['customer_email']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                        <td>
                                            <span class="badge <?php
                                                echo match($shipment['status']) {
                                                    'delivered' => 'badge-success',
                                                    'in_transit' => 'badge-info',
                                                    'out_for_delivery' => 'badge-warning',
                                                    'processing' => 'badge-secondary',
                                                    default => 'badge-secondary'
                                                };
                                            ?>">
                                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $shipment['estimated_delivery'] ? date('M d, Y', strtotime($shipment['estimated_delivery'])) : 'TBD'; ?></td>
                                        <td>
                                            <a href="/agent/update-shipment.php?id=<?php echo $shipment['id']; ?>" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.85rem;">Update</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
