<?php
require_once '../includes/config.php';
checkUserType(['agent']);

$db = getDB();
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claim_shipment'])) {
    $shipment_id = intval($_POST['shipment_id']);
    $agent_id = $_SESSION['user_id'];

    $stmt = $db->prepare("UPDATE shipments SET agent_id = ?, status = 'processing' WHERE id = ? AND agent_id IS NULL");
    if ($stmt->execute([$agent_id, $shipment_id])) {
        $stmt = $db->prepare("INSERT INTO tracking_history (shipment_id, status, location, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$shipment_id, 'Processing', 'Assigned to Agent', 'Shipment has been assigned to delivery agent and is being processed.']);
        $success = 'Shipment claimed successfully!';
    }
}

$pending_shipments = $db->query("
    SELECT s.*, u.full_name as customer_name, u.email as customer_email
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    WHERE s.agent_id IS NULL AND s.status IN ('pending', 'processing')
    ORDER BY s.created_at ASC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Shipments - Agent Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Pending Shipments</h1>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h2>Available Shipments (<?php echo count($pending_shipments); ?>)</h2>
                </div>
                <?php if (empty($pending_shipments)): ?>
                    <div style="text-align: center; padding: 60px 20px; color: var(--dark-gray);">
                        <div style="font-size: 4rem; margin-bottom: 20px;">✅</div>
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">All Caught Up!</h3>
                        <p>There are no pending shipments at the moment.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tracking Number</th>
                                    <th>Customer</th>
                                    <th>Pickup Location</th>
                                    <th>Destination</th>
                                    <th>Service Type</th>
                                    <th>Weight</th>
                                    <th>Created</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_shipments as $shipment): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['customer_name']); ?><br>
                                            <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($shipment['customer_email']); ?></small>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['sender_address']); ?><br>
                                            <?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state'] . ' ' . $shipment['sender_zip']); ?>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['recipient_address']); ?><br>
                                            <?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state'] . ' ' . $shipment['recipient_zip']); ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                        <td><?php echo $shipment['package_weight']; ?> lbs</td>
                                        <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="shipment_id" value="<?php echo $shipment['id']; ?>">
                                                <button type="submit" name="claim_shipment" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.85rem;">Claim</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
