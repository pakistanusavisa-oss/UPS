<?php
require_once '../includes/config.php';
checkUserType(['agent']);

$db = getDB();
$agent_id = $_SESSION['user_id'];
$shipment_id = intval($_GET['id'] ?? 0);

$stmt = $db->prepare("
    SELECT s.*, u.full_name as customer_name, u.email as customer_email
    FROM shipments s
    LEFT JOIN users u ON s.customer_id = u.id
    WHERE s.id = ? AND s.agent_id = ?
");
$stmt->execute([$shipment_id, $agent_id]);
$shipment = $stmt->fetch();

if (!$shipment) {
    header('Location: /agent/my-shipments.php');
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $location = sanitize($_POST['location']);
    $description = sanitize($_POST['description']);

    $stmt = $db->prepare("UPDATE shipments SET status = ?, current_location = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
    if ($stmt->execute([$status, $location, $shipment_id])) {
        if ($status === 'delivered') {
            $stmt = $db->prepare("UPDATE shipments SET actual_delivery = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$shipment_id]);
        }

        $stmt = $db->prepare("INSERT INTO tracking_history (shipment_id, status, location, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$shipment_id, $status, $location, $description]);

        $success = 'Shipment updated successfully!';

        $stmt = $db->prepare("SELECT * FROM shipments WHERE id = ?");
        $stmt->execute([$shipment_id]);
        $shipment = array_merge($shipment, $stmt->fetch());
    } else {
        $error = 'Failed to update shipment.';
    }
}

$tracking_history = $db->prepare("SELECT * FROM tracking_history WHERE shipment_id = ? ORDER BY timestamp DESC");
$tracking_history->execute([$shipment_id]);
$tracking_history = $tracking_history->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Shipment - Agent Dashboard</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Update Shipment</h1>
                <a href="/agent/my-shipments.php" class="btn btn-secondary">← Back to My Shipments</a>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                <div class="card">
                    <div class="card-header">
                        <h2>Shipment Details</h2>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <strong style="color: var(--dark-gray);">Tracking Number:</strong>
                        <p style="font-size: 1.2rem; color: var(--ups-brown); font-weight: bold;"><?php echo htmlspecialchars($shipment['tracking_number']); ?></p>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <strong style="color: var(--dark-gray);">Customer:</strong>
                        <p><?php echo htmlspecialchars($shipment['customer_name']); ?><br>
                        <small><?php echo htmlspecialchars($shipment['customer_email']); ?></small></p>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <strong style="color: var(--dark-gray);">Current Status:</strong>
                        <p>
                            <span class="badge <?php
                                echo match($shipment['status']) {
                                    'delivered' => 'badge-success',
                                    'in_transit' => 'badge-info',
                                    'out_for_delivery' => 'badge-warning',
                                    default => 'badge-secondary'
                                };
                            ?>">
                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                            </span>
                        </p>
                    </div>

                    <div style="background-color: var(--light-gray); padding: 20px; border-radius: 6px; margin-bottom: 20px;">
                        <h4 style="color: var(--ups-brown); margin-bottom: 15px;">📍 From</h4>
                        <p><strong><?php echo htmlspecialchars($shipment['sender_name']); ?></strong></p>
                        <p><?php echo htmlspecialchars($shipment['sender_address']); ?></p>
                        <p><?php echo htmlspecialchars($shipment['sender_city'] . ', ' . $shipment['sender_state'] . ' ' . $shipment['sender_zip']); ?></p>
                    </div>

                    <div style="background-color: var(--light-gray); padding: 20px; border-radius: 6px;">
                        <h4 style="color: var(--ups-brown); margin-bottom: 15px;">📍 To</h4>
                        <p><strong><?php echo htmlspecialchars($shipment['recipient_name']); ?></strong></p>
                        <p><?php echo htmlspecialchars($shipment['recipient_address']); ?></p>
                        <p><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state'] . ' ' . $shipment['recipient_zip']); ?></p>
                        <p style="margin-top: 10px;"><strong>Phone:</strong> <?php echo htmlspecialchars($shipment['recipient_phone']); ?></p>
                    </div>
                </div>

                <div>
                    <div class="card">
                        <div class="card-header">
                            <h2>Update Status</h2>
                        </div>

                        <form method="POST">
                            <div class="form-group">
                                <label>Status *</label>
                                <select name="status" required>
                                    <option value="processing" <?php echo $shipment['status'] === 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="in_transit" <?php echo $shipment['status'] === 'in_transit' ? 'selected' : ''; ?>>In Transit</option>
                                    <option value="out_for_delivery" <?php echo $shipment['status'] === 'out_for_delivery' ? 'selected' : ''; ?>>Out for Delivery</option>
                                    <option value="delivered" <?php echo $shipment['status'] === 'delivered' ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="exception">Exception/Delayed</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Current Location *</label>
                                <input type="text" name="location" value="<?php echo htmlspecialchars($shipment['current_location']); ?>" placeholder="e.g., New York Distribution Center" required>
                            </div>

                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" rows="4" placeholder="Add notes about this update..."></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px;">Update Shipment</button>
                        </form>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h2>Tracking History</h2>
                        </div>
                        <div style="max-height: 400px; overflow-y: auto;">
                            <?php foreach ($tracking_history as $history): ?>
                                <div style="padding: 15px; border-bottom: 1px solid var(--medium-gray);">
                                    <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                        <strong style="color: var(--ups-brown);"><?php echo htmlspecialchars($history['status']); ?></strong>
                                        <span style="color: var(--dark-gray); font-size: 0.85rem;"><?php echo date('M d, Y g:i A', strtotime($history['timestamp'])); ?></span>
                                    </div>
                                    <?php if ($history['location']): ?>
                                        <p style="color: var(--dark-gray); font-size: 0.9rem; margin-bottom: 5px;">📍 <?php echo htmlspecialchars($history['location']); ?></p>
                                    <?php endif; ?>
                                    <?php if ($history['description']): ?>
                                        <p style="font-size: 0.9rem;"><?php echo htmlspecialchars($history['description']); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
