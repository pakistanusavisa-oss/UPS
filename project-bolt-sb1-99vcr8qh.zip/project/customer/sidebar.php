<div class="dashboard-sidebar">
    <div class="user-info">
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
        </div>
        <h3><?php echo htmlspecialchars($_SESSION['user_name']); ?></h3>
        <p style="opacity: 0.8; font-size: 0.9rem;">Customer</p>
    </div>

    <nav>
        <ul>
            <li><a href="/customer/dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>">📊 Dashboard</a></li>
            <li><a href="/customer/create-shipment.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'create-shipment.php' ? 'active' : ''; ?>">➕ New Shipment</a></li>
            <li><a href="/customer/shipments.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'shipments.php' ? 'active' : ''; ?>">📦 My Shipments</a></li>
            <li><a href="/customer/profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) === 'profile.php' ? 'active' : ''; ?>">👤 Profile</a></li>
            <li><a href="/" style="border-top: 1px solid rgba(255,255,255,0.1); margin-top: 20px; padding-top: 20px;">🏠 Main Site</a></li>
            <li><a href="/logout.php">🚪 Logout</a></li>
        </ul>
    </nav>
</div>
