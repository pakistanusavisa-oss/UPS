<?php
require_once '../includes/config.php';
checkUserType(['customer']);

$db = getDB();
$success = false;
$error = '';
$tracking_number = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender_name = sanitize($_POST['sender_name']);
    $sender_phone = sanitize($_POST['sender_phone']);
    $sender_address = sanitize($_POST['sender_address']);
    $sender_city = sanitize($_POST['sender_city']);
    $sender_state = sanitize($_POST['sender_state']);
    $sender_zip = sanitize($_POST['sender_zip']);
    $sender_country = sanitize($_POST['sender_country']);

    $recipient_name = sanitize($_POST['recipient_name']);
    $recipient_phone = sanitize($_POST['recipient_phone']);
    $recipient_address = sanitize($_POST['recipient_address']);
    $recipient_city = sanitize($_POST['recipient_city']);
    $recipient_state = sanitize($_POST['recipient_state']);
    $recipient_zip = sanitize($_POST['recipient_zip']);
    $recipient_country = sanitize($_POST['recipient_country']);

    $package_weight = floatval($_POST['package_weight']);
    $package_dimensions = sanitize($_POST['package_dimensions']);
    $package_description = sanitize($_POST['package_description']);
    $service_type = sanitize($_POST['service_type']);

    $shipping_cost = match($service_type) {
        'UPS Express Plus' => 89.99,
        'UPS Next Day Air' => 69.99,
        'UPS 2nd Day Air' => 39.99,
        'UPS Ground' => 19.99,
        'International Express' => 129.99,
        default => 29.99
    };

    $tracking_number = generateTrackingNumber();

    $estimated_delivery = match($service_type) {
        'UPS Express Plus' => date('Y-m-d', strtotime('+1 day')),
        'UPS Next Day Air' => date('Y-m-d', strtotime('+1 day')),
        'UPS 2nd Day Air' => date('Y-m-d', strtotime('+2 days')),
        'UPS Ground' => date('Y-m-d', strtotime('+5 days')),
        'International Express' => date('Y-m-d', strtotime('+3 days')),
        default => date('Y-m-d', strtotime('+7 days'))
    };

    try {
        $stmt = $db->prepare("
            INSERT INTO shipments (
                tracking_number, customer_id,
                sender_name, sender_phone, sender_address, sender_city, sender_state, sender_zip, sender_country,
                recipient_name, recipient_phone, recipient_address, recipient_city, recipient_state, recipient_zip, recipient_country,
                package_weight, package_dimensions, package_description, service_type, shipping_cost, estimated_delivery, status, current_location
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'Processing at origin facility')
        ");

        $stmt->execute([
            $tracking_number, $_SESSION['user_id'],
            $sender_name, $sender_phone, $sender_address, $sender_city, $sender_state, $sender_zip, $sender_country,
            $recipient_name, $recipient_phone, $recipient_address, $recipient_city, $recipient_state, $recipient_zip, $recipient_country,
            $package_weight, $package_dimensions, $package_description, $service_type, $shipping_cost, $estimated_delivery
        ]);

        $shipment_id = $db->lastInsertId();

        $stmt = $db->prepare("INSERT INTO tracking_history (shipment_id, status, location, description) VALUES (?, ?, ?, ?)");
        $stmt->execute([$shipment_id, 'Label Created', 'Origin Facility', 'Shipping label has been created and shipment is being processed.']);

        $success = true;
    } catch (Exception $e) {
        $error = 'Failed to create shipment. Please try again.';
    }
}

$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Shipment - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">Create New Shipment</h1>
            </div>

            <?php if ($success): ?>
                <div class="card" style="max-width: 600px; margin: 0 auto; text-align: center; padding: 50px;">
                    <div style="font-size: 4rem; color: var(--success); margin-bottom: 20px;">✅</div>
                    <h2 style="color: var(--ups-brown); margin-bottom: 15px;">Shipment Created Successfully!</h2>
                    <p style="color: var(--dark-gray); margin-bottom: 25px;">Your tracking number is:</p>
                    <div style="background-color: var(--light-gray); padding: 20px; border-radius: 8px; margin-bottom: 30px;">
                        <strong style="font-size: 1.5rem; color: var(--ups-brown);"><?php echo $tracking_number; ?></strong>
                    </div>
                    <div style="display: flex; gap: 15px; justify-content: center;">
                        <a href="/tracking.php?tracking=<?php echo $tracking_number; ?>" class="btn btn-primary">Track Shipment</a>
                        <a href="/customer/create-shipment.php" class="btn btn-secondary">Create Another</a>
                    </div>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="card">
                    <form method="POST">
                        <div class="card-header">
                            <h2>Sender Information</h2>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label>Sender Name *</label>
                                <input type="text" name="sender_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Sender Phone *</label>
                                <input type="tel" name="sender_phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Sender Address *</label>
                            <input type="text" name="sender_address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>" required>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label>City *</label>
                                <input type="text" name="sender_city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>State *</label>
                                <input type="text" name="sender_state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>ZIP Code *</label>
                                <input type="text" name="sender_zip" value="<?php echo htmlspecialchars($user['zip_code'] ?? ''); ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Country *</label>
                                <select name="sender_country" required>
                                    <option value="USA" <?php echo ($user['country'] ?? '') === 'USA' ? 'selected' : ''; ?>>USA</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="UK">UK</option>
                                </select>
                            </div>
                        </div>

                        <div class="card-header" style="margin-top: 30px;">
                            <h2>Recipient Information</h2>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label>Recipient Name *</label>
                                <input type="text" name="recipient_name" required>
                            </div>

                            <div class="form-group">
                                <label>Recipient Phone *</label>
                                <input type="tel" name="recipient_phone" required>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Recipient Address *</label>
                            <input type="text" name="recipient_address" required>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label>City *</label>
                                <input type="text" name="recipient_city" required>
                            </div>

                            <div class="form-group">
                                <label>State *</label>
                                <input type="text" name="recipient_state" required>
                            </div>

                            <div class="form-group">
                                <label>ZIP Code *</label>
                                <input type="text" name="recipient_zip" required>
                            </div>

                            <div class="form-group">
                                <label>Country *</label>
                                <select name="recipient_country" required>
                                    <option value="USA">USA</option>
                                    <option value="Canada">Canada</option>
                                    <option value="Mexico">Mexico</option>
                                    <option value="UK">UK</option>
                                </select>
                            </div>
                        </div>

                        <div class="card-header" style="margin-top: 30px;">
                            <h2>Package Details</h2>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label>Weight (lbs) *</label>
                                <input type="number" name="package_weight" step="0.1" min="0.1" required>
                            </div>

                            <div class="form-group">
                                <label>Dimensions (L x W x H)</label>
                                <input type="text" name="package_dimensions" placeholder="12 x 8 x 6 inches">
                            </div>

                            <div class="form-group">
                                <label>Service Type *</label>
                                <select name="service_type" required id="serviceType" onchange="updateCost()">
                                    <option value="UPS Express Plus">UPS Express Plus ($89.99)</option>
                                    <option value="UPS Next Day Air">UPS Next Day Air ($69.99)</option>
                                    <option value="UPS 2nd Day Air">UPS 2nd Day Air ($39.99)</option>
                                    <option value="UPS Ground" selected>UPS Ground ($19.99)</option>
                                    <option value="International Express">International Express ($129.99)</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Package Description</label>
                            <textarea name="package_description" rows="3" placeholder="Describe the contents of your package"></textarea>
                        </div>

                        <div style="background-color: #fffbf0; padding: 20px; border-radius: 8px; margin-top: 20px; border-left: 4px solid var(--ups-gold);">
                            <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Estimated Cost</h3>
                            <p style="font-size: 2rem; color: var(--ups-brown); font-weight: bold;" id="costDisplay">$19.99</p>
                        </div>

                        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; margin-top: 30px;">
                            Create Shipment
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function updateCost() {
            const serviceType = document.getElementById('serviceType').value;
            const costs = {
                'UPS Express Plus': '$89.99',
                'UPS Next Day Air': '$69.99',
                'UPS 2nd Day Air': '$39.99',
                'UPS Ground': '$19.99',
                'International Express': '$129.99'
            };
            document.getElementById('costDisplay').textContent = costs[serviceType] || '$0.00';
        }
    </script>
</body>
</html>
