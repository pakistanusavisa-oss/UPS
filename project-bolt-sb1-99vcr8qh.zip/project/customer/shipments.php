<?php
require_once '../includes/config.php';
checkUserType(['customer']);

$db = getDB();
$user_id = $_SESSION['user_id'];

$shipments = $db->prepare("SELECT * FROM shipments WHERE customer_id = ? ORDER BY created_at DESC");
$shipments->execute([$user_id]);
$shipments = $shipments->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shipments - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">My Shipments</h1>
                <a href="/customer/create-shipment.php" class="btn btn-primary">+ Create New Shipment</a>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>All Shipments (<?php echo count($shipments); ?>)</h2>
                </div>
                <?php if (empty($shipments)): ?>
                    <div style="text-align: center; padding: 60px 20px; color: var(--dark-gray);">
                        <div style="font-size: 4rem; margin-bottom: 20px;">📦</div>
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">No Shipments Yet</h3>
                        <p style="margin-bottom: 25px;">Create your first shipment to get started!</p>
                        <a href="/customer/create-shipment.php" class="btn btn-primary">Create Shipment</a>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tracking Number</th>
                                    <th>Recipient</th>
                                    <th>Destination</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Cost</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($shipments as $shipment): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($shipment['recipient_name']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state'] . ', ' . $shipment['recipient_country']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                        <td>
                                            <span class="badge <?php
                                                echo match($shipment['status']) {
                                                    'delivered' => 'badge-success',
                                                    'in_transit' => 'badge-info',
                                                    'out_for_delivery' => 'badge-warning',
                                                    'pending' => 'badge-secondary',
                                                    default => 'badge-secondary'
                                                };
                                            ?>">
                                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo formatCurrency($shipment['shipping_cost']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                        <td>
                                            <a href="/tracking.php?tracking=<?php echo $shipment['tracking_number']; ?>" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.85rem;">Track</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
