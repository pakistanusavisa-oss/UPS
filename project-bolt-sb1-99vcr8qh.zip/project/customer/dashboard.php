<?php
require_once '../includes/config.php';
checkUserType(['customer']);

$db = getDB();
$user_id = $_SESSION['user_id'];

$total_shipments = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE customer_id = ?");
$total_shipments->execute([$user_id]);
$total_shipments = $total_shipments->fetch()['count'];

$in_transit = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE customer_id = ? AND status IN ('in_transit', 'out_for_delivery')");
$in_transit->execute([$user_id]);
$in_transit = $in_transit->fetch()['count'];

$delivered = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE customer_id = ? AND status = 'delivered'");
$delivered->execute([$user_id]);
$delivered = $delivered->fetch()['count'];

$pending = $db->prepare("SELECT COUNT(*) as count FROM shipments WHERE customer_id = ? AND status = 'pending'");
$pending->execute([$user_id]);
$pending = $pending->fetch()['count'];

$recent_shipments = $db->prepare("
    SELECT * FROM shipments
    WHERE customer_id = ?
    ORDER BY created_at DESC
    LIMIT 5
");
$recent_shipments->execute([$user_id]);
$recent_shipments = $recent_shipments->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">My Dashboard</h1>
                <a href="/customer/create-shipment.php" class="btn btn-primary">+ Create New Shipment</a>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-value"><?php echo $total_shipments; ?></div>
                    <div class="stat-label">Total Shipments</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">🚚</div>
                    <div class="stat-value"><?php echo $in_transit; ?></div>
                    <div class="stat-label">In Transit</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">✅</div>
                    <div class="stat-value"><?php echo $delivered; ?></div>
                    <div class="stat-label">Delivered</div>
                </div>

                <div class="stat-card">
                    <div class="stat-icon">⏳</div>
                    <div class="stat-value"><?php echo $pending; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Recent Shipments</h2>
                </div>
                <?php if (empty($recent_shipments)): ?>
                    <div style="text-align: center; padding: 60px 20px; color: var(--dark-gray);">
                        <div style="font-size: 4rem; margin-bottom: 20px;">📦</div>
                        <h3 style="color: var(--ups-brown); margin-bottom: 15px;">No Shipments Yet</h3>
                        <p style="margin-bottom: 25px;">Create your first shipment to get started!</p>
                        <a href="/customer/create-shipment.php" class="btn btn-primary">Create Shipment</a>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Tracking Number</th>
                                    <th>To</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_shipments as $shipment): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($shipment['tracking_number']); ?></strong></td>
                                        <td>
                                            <?php echo htmlspecialchars($shipment['recipient_name']); ?><br>
                                            <small style="color: var(--dark-gray);"><?php echo htmlspecialchars($shipment['recipient_city'] . ', ' . $shipment['recipient_state']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($shipment['service_type']); ?></td>
                                        <td>
                                            <span class="badge <?php
                                                echo match($shipment['status']) {
                                                    'delivered' => 'badge-success',
                                                    'in_transit' => 'badge-info',
                                                    'out_for_delivery' => 'badge-warning',
                                                    'pending' => 'badge-secondary',
                                                    default => 'badge-secondary'
                                                };
                                            ?>">
                                                <?php echo strtoupper(str_replace('_', ' ', $shipment['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                        <td>
                                            <a href="/tracking.php?tracking=<?php echo $shipment['tracking_number']; ?>" class="btn btn-primary" style="padding: 5px 15px; font-size: 0.85rem;">Track</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div style="text-align: center; padding: 20px;">
                        <a href="/customer/shipments.php" style="color: var(--ups-gold); font-weight: 600;">View All Shipments →</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
