<?php
require_once '../includes/config.php';
checkUserType(['customer']);

$db = getDB();
$success = '';
$error = '';
$user = getCurrentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = sanitize($_POST['full_name']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);
    $city = sanitize($_POST['city']);
    $state = sanitize($_POST['state']);
    $zip_code = sanitize($_POST['zip_code']);
    $country = sanitize($_POST['country']);

    $stmt = $db->prepare("
        UPDATE users
        SET full_name = ?, phone = ?, address = ?, city = ?, state = ?, zip_code = ?, country = ?
        WHERE id = ?
    ");

    if ($stmt->execute([$full_name, $phone, $address, $city, $state, $zip_code, $country, $_SESSION['user_id']])) {
        $success = 'Profile updated successfully!';
        $_SESSION['user_name'] = $full_name;
        $user = getCurrentUser();
    } else {
        $error = 'Failed to update profile.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - UPS Logistics</title>
    <link rel="stylesheet" href="/css/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <?php include 'sidebar.php'; ?>

        <div class="dashboard-main">
            <div class="dashboard-header">
                <h1 style="color: var(--ups-brown);">My Profile</h1>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="card" style="max-width: 800px;">
                <div class="card-header">
                    <h2>Personal Information</h2>
                </div>

                <form method="POST">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly style="background-color: var(--light-gray);">
                        <small style="color: var(--dark-gray);">Email cannot be changed</small>
                    </div>

                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label>Street Address</label>
                        <input type="text" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label>State</label>
                            <input type="text" name="state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>">
                        </div>

                        <div class="form-group">
                            <label>ZIP Code</label>
                            <input type="text" name="zip_code" value="<?php echo htmlspecialchars($user['zip_code'] ?? ''); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Country</label>
                        <select name="country">
                            <option value="USA" <?php echo ($user['country'] ?? '') === 'USA' ? 'selected' : ''; ?>>United States</option>
                            <option value="Canada" <?php echo ($user['country'] ?? '') === 'Canada' ? 'selected' : ''; ?>>Canada</option>
                            <option value="Mexico" <?php echo ($user['country'] ?? '') === 'Mexico' ? 'selected' : ''; ?>>Mexico</option>
                            <option value="UK" <?php echo ($user['country'] ?? '') === 'UK' ? 'selected' : ''; ?>>United Kingdom</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="padding: 12px 40px;">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
