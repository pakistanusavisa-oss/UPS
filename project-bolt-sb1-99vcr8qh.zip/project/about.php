<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - UPS Logistics</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <section style="background: linear-gradient(135deg, var(--ups-brown) 0%, var(--ups-dark-brown) 100%); color: white; padding: 80px 0; text-align: center;">
        <div class="container">
            <h1 style="font-size: 3rem; margin-bottom: 15px;">About UPS Logistics</h1>
            <p style="font-size: 1.2rem; opacity: 0.9;">Moving at the speed of business since 1907</p>
        </div>
    </section>

    <section style="padding: 80px 0;">
        <div class="container">
            <div style="max-width: 800px; margin: 0 auto;">
                <h2 style="color: var(--ups-brown); font-size: 2.5rem; margin-bottom: 30px; text-align: center;">Our Story</h2>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px; color: var(--text-dark);">
                    Founded over a century ago, UPS has grown from a small messenger company to become the world's largest package delivery company and a leading provider of specialized transportation and logistics services.
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; margin-bottom: 20px; color: var(--text-dark);">
                    Today, we operate in more than 220 countries and territories worldwide, delivering an average of 24 million packages per day. Our global network connects businesses and consumers through a combination of leading-edge technology and dedicated employees committed to excellence.
                </p>
                <p style="font-size: 1.1rem; line-height: 1.8; color: var(--text-dark);">
                    We continue to invest in innovative solutions and sustainable practices to meet the evolving needs of our customers while maintaining our commitment to reliability, security, and environmental responsibility.
                </p>
            </div>
        </div>
    </section>

    <section style="background-color: var(--light-gray); padding: 80px 0;">
        <div class="container">
            <h2 class="section-title">Why Choose UPS</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px; margin-top: 50px;">
                <div style="text-align: center;">
                    <div style="font-size: 4rem; color: var(--ups-gold); margin-bottom: 15px;">220+</div>
                    <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Countries Served</h3>
                    <p style="color: var(--dark-gray);">Global reach with local expertise</p>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 4rem; color: var(--ups-gold); margin-bottom: 15px;">24M</div>
                    <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Daily Packages</h3>
                    <p style="color: var(--dark-gray);">Delivering millions of packages every day</p>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 4rem; color: var(--ups-gold); margin-bottom: 15px;">500K+</div>
                    <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Employees</h3>
                    <p style="color: var(--dark-gray);">Dedicated team members worldwide</p>
                </div>
                <div style="text-align: center;">
                    <div style="font-size: 4rem; color: var(--ups-gold); margin-bottom: 15px;">117+</div>
                    <h3 style="color: var(--ups-brown); margin-bottom: 10px;">Years of Service</h3>
                    <p style="color: var(--dark-gray);">Over a century of logistics excellence</p>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 80px 0;">
        <div class="container">
            <h2 class="section-title">Our Values</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 40px;">
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3>Customer First</h3>
                    <p>We put our customers at the center of everything we do, delivering solutions that exceed expectations.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🤝</div>
                    <h3>Integrity</h3>
                    <p>We conduct our business with honesty, transparency, and respect for all stakeholders.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">💡</div>
                    <h3>Innovation</h3>
                    <p>We continuously invest in technology and processes to improve efficiency and service quality.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🌱</div>
                    <h3>Sustainability</h3>
                    <p>We're committed to reducing our environmental impact through sustainable business practices.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3>Excellence</h3>
                    <p>We strive for excellence in every shipment, every interaction, and every solution we provide.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">👥</div>
                    <h3>Teamwork</h3>
                    <p>We believe in the power of collaboration and work together to achieve common goals.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="background: linear-gradient(135deg, var(--ups-gold) 0%, var(--ups-light-gold) 100%); padding: 80px 0; text-align: center;">
        <div class="container">
            <h2 style="color: var(--ups-brown); font-size: 2.5rem; margin-bottom: 20px;">Join the UPS Family</h2>
            <p style="font-size: 1.2rem; margin-bottom: 30px; color: var(--ups-brown);">Experience the difference of working with a global logistics leader.</p>
            <a href="/register.php" class="btn btn-primary" style="background: var(--ups-brown); color: white; font-size: 1.1rem; padding: 15px 40px;">Get Started Today</a>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
