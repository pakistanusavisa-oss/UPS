import { TrackingWidget } from "@/components/TrackingWidget";

export default function Tracking() {
  return (
    <div className="bg-muted/30 min-h-[calc(100vh-theme(spacing.20))]">
      <div className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-heading font-bold uppercase">Track Shipment</h1>
          <p className="mt-2 text-primary-foreground/80">Real-time visibility into your supply chain.</p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-12">
        <TrackingWidget />
        
        <div className="max-w-4xl mx-auto mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-heading font-bold text-lg mb-2">Tracking Help</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Enter your tracking number exactly as it appears on your receipt or confirmation email. Tracking numbers are usually 10-18 characters long.
            </p>
            <a href="#" className="text-primary font-bold text-sm hover:underline">View Tracking FAQ &rarr;</a>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <h3 className="font-heading font-bold text-lg mb-2">Manage Deliveries</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Sign up for UPS MyChoice to redirect packages, schedule deliveries, and get delivery alerts.
            </p>
            <a href="#" className="text-primary font-bold text-sm hover:underline">Sign Up for Free &rarr;</a>
          </div>
        </div>
      </div>
    </div>
  );
}
