import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function About() {
  return (
    <div>
      <div className="bg-primary text-primary-foreground py-20">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-heading font-bold uppercase mb-4">About UPS</h1>
          <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
            A legacy of trust, innovation, and global connectivity.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16 space-y-20">
        {/* Story Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-heading font-bold text-primary uppercase">Our Story</h2>
            <div className="w-20 h-1 bg-secondary"></div>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Founded in 1995, UPS Logistics began with a single truck and a vision to simplify supply chains. Today, we are a global leader in logistics, operating in over 220 countries and territories.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Our mission is simple: To connect people and possibilities. By combining advanced technology with human expertise, we ensure your goods arrive safely and on time, every time.
            </p>
            <p className="text-xs text-muted-foreground bg-muted border rounded px-3 py-2" data-testid="text-about-disclaimer">
              This experience is a design prototype for demonstration purposes only and is <span className="font-semibold">not affiliated with or endorsed by United Parcel Service (UPS)</span>. Names and locations are illustrative.
            </p>
          </div>
          <div className="bg-muted aspect-video rounded-lg flex items-center justify-center border-4 border-white shadow-xl">
            <span className="text-muted-foreground font-medium">Company Headquarters Image</span>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-zinc-900 text-white p-12 rounded-xl shadow-2xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
             <div>
               <div className="text-4xl md:text-5xl font-bold text-secondary mb-2">220+</div>
               <div className="text-sm uppercase tracking-wider opacity-80">Countries Served</div>
             </div>
             <div>
               <div className="text-4xl md:text-5xl font-bold text-secondary mb-2">5.5B</div>
               <div className="text-sm uppercase tracking-wider opacity-80">Packages Annually</div>
             </div>
             <div>
               <div className="text-4xl md:text-5xl font-bold text-secondary mb-2">500k+</div>
               <div className="text-sm uppercase tracking-wider opacity-80">Employees</div>
             </div>
             <div>
               <div className="text-4xl md:text-5xl font-bold text-secondary mb-2">24/7</div>
               <div className="text-sm uppercase tracking-wider opacity-80">Customer Support</div>
             </div>
          </div>
        </div>

        {/* Leadership/Values */}
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-heading font-bold text-primary mb-12 uppercase">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 border rounded-lg hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-xl mb-3">Integrity</h3>
              <p className="text-muted-foreground">We do what we say we will do. Trust is our currency.</p>
            </div>
            <div className="p-6 border rounded-lg hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-xl mb-3">Innovation</h3>
              <p className="text-muted-foreground">We constantly adapt and evolve to meet modern challenges.</p>
            </div>
            <div className="p-6 border rounded-lg hover:shadow-lg transition-shadow">
              <h3 className="font-bold text-xl mb-3">Sustainability</h3>
              <p className="text-muted-foreground">Committed to reducing our carbon footprint for a greener future.</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h2 className="text-2xl font-heading font-bold mb-4 uppercase">Want to see the platform in action?</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto text-sm md:text-base">
            Explore tracking, quoting, and global locations on this demo to get a feel for how a modern logistics interface can work.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link href="/tracking">
              <Button variant="outline" data-testid="button-about-track">Try Tracking</Button>
            </Link>
            <Link href="/locations">
              <Button className="bg-primary text-primary-foreground" data-testid="button-about-locations">View Locations Map</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
