import { Suspense, lazy } from "react";
import { Skeleton } from "@/components/ui/skeleton";

const LocationsMap = lazy(() => import("@/components/LocationsMap").then((m) => ({ default: m.LocationsMap })));

export default function LocationsPage() {
  return (
    <div className="bg-muted/30 min-h-screen">
      <header className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-heading font-bold uppercase">Locations</h1>
          <p className="mt-2 text-primary-foreground/80 max-w-2xl text-sm md:text-base">
            Explore a curated map of major UPS hubs and illustrative demo locations across the globe.
          </p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-10 space-y-8">
        <Suspense
          fallback={
            <div className="space-y-4" aria-label="Loading locations map">
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-80 w-full rounded-xl" />
            </div>
          }
        >
          <LocationsMap />
        </Suspense>

        <p className="text-[11px] text-muted-foreground max-w-3xl" data-testid="text-locations-disclaimer">
          This site is a design prototype for demonstration purposes only and is <span className="font-semibold">not
          affiliated with or endorsed by United Parcel Service (UPS)</span>. All locations and metrics are illustrative
          and may not reflect the actual UPS network.
        </p>
      </main>
    </div>
  );
}
