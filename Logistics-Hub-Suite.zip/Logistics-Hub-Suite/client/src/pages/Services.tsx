import { MOCK_SERVICES } from "@/lib/mockData";
import { ServiceCard } from "@/components/ServiceCard";
import { Check } from "lucide-react";

export default function Services() {
  return (
    <div>
      <div className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-5xl font-heading font-bold uppercase mb-4">Our Services</h1>
          <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
            End-to-end logistics solutions tailored to your industry and business needs.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {MOCK_SERVICES.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl font-heading font-bold text-primary mb-6 uppercase">Industry Solutions</h2>
            <p className="text-muted-foreground mb-6 leading-relaxed">
              We understand that every industry has unique logistics challenges. Our specialized teams provide tailored solutions for:
            </p>
            <ul className="space-y-4">
              {["Automotive", "Healthcare & Pharma", "Retail & E-commerce", "Technology", "Aerospace"].map((item) => (
                <li key={item} className="flex items-center gap-3">
                  <div className="h-6 w-6 rounded-full bg-green-100 text-green-600 flex items-center justify-center">
                    <Check className="h-4 w-4" />
                  </div>
                  <span className="font-medium text-lg">{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-muted rounded-lg p-8 border border-border">
            <h3 className="text-2xl font-heading font-bold mb-4">Need a Custom Solution?</h3>
            <p className="text-muted-foreground mb-6">
              Our logistics engineers can design a custom supply chain model that optimizes costs and improves speed to market.
            </p>
            <button className="bg-primary text-primary-foreground px-6 py-3 font-bold uppercase rounded hover:bg-primary/90 transition-colors">
              Contact Sales
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
