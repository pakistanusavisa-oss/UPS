import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function Readme() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-4xl">
      <h1 className="text-4xl font-heading font-bold mb-8 uppercase text-primary">System Documentation</h1>
      
      <div className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Project Overview</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p>
              This is a high-fidelity <strong>React Prototype</strong> designed to simulate the functionality of a full PHP/MySQL Logistics Platform. 
              It is built for design validation, UX testing, and frontend development.
            </p>
            <div className="bg-yellow-50 border border-yellow-200 p-4 rounded text-yellow-800 text-sm">
              <strong>Note:</strong> As this is a prototype environment, all data (shipments, users, quotes) is mock data stored in memory. 
              No actual database connection or server-side PHP processing is currently active.
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Features Implemented</CardTitle>
          </CardHeader>
          <CardContent>
             <ul className="space-y-2">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-600" /> <strong>Shipment Tracking:</strong> Real-time status updates (Mock Data).</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-600" /> <strong>Quote System:</strong> Complex form with client-side validation.</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-600" /> <strong>Admin Dashboard:</strong> Protected route with shipment management view.</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-600" /> <strong>Responsive Design:</strong> Fully mobile-optimized UI.</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Configuration & Credential Info</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-bold mb-2">Admin Credentials</h3>
              <p className="text-sm text-muted-foreground mb-2">Use these credentials to access the Employee Dashboard:</p>
              <ul className="list-disc pl-5 text-sm font-mono">
                <li>Email: <strong>admin@fullups.com</strong></li>
                <li>Password: <strong>admin</strong></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2">Sample Tracking Numbers</h3>
              <p className="text-sm text-muted-foreground mb-2">Test the tracking widget with these IDs:</p>
              <ul className="list-disc pl-5 text-sm font-mono">
                <li>UPS123456789 (In Transit)</li>
                <li>UPS987654321 (Delivered)</li>
                <li>UPS555555555 (Exception)</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
