import { QuoteForm } from "@/components/QuoteForm";

export default function Quote() {
  return (
    <div className="bg-muted/30 min-h-screen pb-20">
      <div className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-heading font-bold uppercase">Get a Quote</h1>
          <p className="mt-2 text-primary-foreground/80">Competitive pricing for domestic and international shipping.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 -mt-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <QuoteForm />
          </div>
          <div className="space-y-6 lg:mt-24">
            <div className="bg-white p-6 rounded-lg shadow-md border border-l-4 border-l-secondary">
              <h3 className="font-heading font-bold text-xl mb-4 text-primary">Why Quote with Us?</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2"><span className="text-green-500">✓</span> Instant estimated rates</li>
                <li className="flex gap-2"><span className="text-green-500">✓</span> Guaranteed capacity</li>
                <li className="flex gap-2"><span className="text-green-500">✓</span> 24/7 Support included</li>
                <li className="flex gap-2"><span className="text-green-500">✓</span> Carbon neutral options</li>
              </ul>
            </div>
            
            <div className="bg-primary text-primary-foreground p-6 rounded-lg shadow-md">
              <h3 className="font-heading font-bold text-xl mb-2">Need Help?</h3>
              <p className="text-sm opacity-80 mb-4">Call our sales team directly for complex shipments.</p>
              <p className="text-2xl font-bold text-secondary">1-800-UPS-FULL</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
