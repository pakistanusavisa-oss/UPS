import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Contact() {
  return (
    <div>
      <div className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-heading font-bold uppercase mb-4">Contact Us</h1>
          <p className="text-xl text-primary-foreground/80">We're here to help with your shipping needs.</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div>
            <h2 className="text-3xl font-heading font-bold text-primary mb-8 uppercase">Get In Touch</h2>
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded text-secondary-foreground">
                  <MapPin className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Global Headquarters</h4>
                  <p className="text-muted-foreground">123 Logistics Way<br />Atlanta, GA 30303<br />United States</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded text-secondary-foreground">
                  <Phone className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Phone Support</h4>
                  <p className="text-muted-foreground">1-800-UPS-FULL (Domestic)</p>
                  <p className="text-muted-foreground">+1-404-555-0199 (International)</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded text-secondary-foreground">
                  <Mail className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Email</h4>
                  <p className="text-muted-foreground">support@fullupslogistics.com</p>
                  <p className="text-muted-foreground">sales@fullupslogistics.com</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-secondary/10 p-3 rounded text-secondary-foreground">
                  <Clock className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Hours of Operation</h4>
                  <p className="text-muted-foreground">Monday - Friday: 08:00 - 20:00 EST</p>
                  <p className="text-muted-foreground">Saturday: 09:00 - 17:00 EST</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white p-8 rounded-lg shadow-lg border">
            <h3 className="text-2xl font-heading font-bold mb-6">Send us a Message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">First Name</label>
                  <Input placeholder="John" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Last Name</label>
                  <Input placeholder="Doe" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Email</label>
                <Input type="email" placeholder="john@example.com" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Subject</label>
                <Input placeholder="Tracking Inquiry" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Message</label>
                <Textarea placeholder="How can we help you?" className="min-h-[120px]" />
              </div>

              <Button className="w-full bg-primary text-primary-foreground font-bold uppercase tracking-wide hover:bg-primary/90">
                Send Message
              </Button>
            </form>
          </div>
        </div>

        {/* Placeholder Map */}
        <div className="mt-16 h-[400px] bg-muted rounded-lg flex items-center justify-center border relative overflow-hidden group">
          <div className="absolute inset-0 bg-slate-200" style={{backgroundImage: "radial-gradient(#cbd5e1 1px, transparent 1px)", backgroundSize: "20px 20px"}}></div>
          <div className="relative z-10 text-center">
            <MapPin className="h-12 w-12 text-primary mx-auto mb-4 animate-bounce" />
            <h3 className="text-xl font-bold text-primary">Interactive Network Map</h3>
            <p className="text-muted-foreground">Loading global coverage data...</p>
          </div>
        </div>
      </div>
    </div>
  );
}
