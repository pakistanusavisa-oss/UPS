import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Package } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [location, setLocation] = useLocation();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (email === "admin@ups-demo.com" && password === "admin") {
      localStorage.setItem("isAdmin", "true");
      setLocation("/admin");
    } else {
      setError("Invalid credentials. Try admin@ups-demo.com / admin");
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-muted/30">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-xl border">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-primary text-primary-foreground p-3 rounded mb-4">
            <Package className="h-8 w-8" />
          </div>
          <h2 className="text-2xl font-heading font-bold uppercase text-primary">Employee Login</h2>
          <p className="text-sm text-muted-foreground">Access the Logistics Management System (demo)</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded text-sm text-center" data-testid="status-login-error">
              {error}
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-medium">Email Address</label>
            <Input 
              type="email" 
              placeholder="admin@ups-demo.com" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              data-testid="input-login-email"
            />
          </div>

          <div className="space-y-2">
             <div className="flex justify-between">
              <label className="text-sm font-medium">Password</label>
              <a href="#" className="text-xs text-primary hover:underline">Forgot password?</a>
            </div>
            <Input 
              type="password" 
              placeholder="•••••" 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              data-testid="input-login-password"
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-primary text-primary-foreground font-bold uppercase tracking-wide hover:bg-primary/90"
            data-testid="button-login-submit"
          >
            Sign In
          </Button>
        </form>

        <div className="mt-6 text-center text-xs text-muted-foreground" data-testid="text-login-disclaimer">
          This login is part of a demo interface only and does not connect to live UPS systems.
        </div>
      </div>
    </div>
  );
}
