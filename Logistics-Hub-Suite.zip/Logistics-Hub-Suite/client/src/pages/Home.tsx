import { TrackingWidget } from "@/components/TrackingWidget";
import { ServiceCard } from "@/components/ServiceCard";
import { MOCK_SERVICES } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import heroImage from "@/assets/hero-logistics.png";
import {
  ArrowRight,
  Globe,
  ShieldCheck,
  Clock,
  CheckCircle2,
  Leaf,
  MapPin,
  Radar,
  Cpu,
  LineChart,
  MapPinned,
} from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function Home() {
  return (
    <div className="flex flex-col">
      {/* HERO: Extended with trust badges & KPIs */}
      <section className="relative flex items-center justify-center overflow-hidden bg-black text-white">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={heroImage}
            alt="UPS Logistics global fleet"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/65 to-black/10" />
        </div>

        <div className="container mx-auto px-4 py-20 lg:py-28 z-10 relative grid grid-cols-1 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)] gap-12 items-center">
          {/* Hero Copy */}
          <div className="space-y-8 max-w-xl">
            <p className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-secondary">
              <span className="h-2 w-2 rounded-full bg-green-400 animate-pulse" aria-hidden="true" />
              Trusted Global Logistics Partner
            </p>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-heading font-bold leading-tight">
              Moving the <span className="text-secondary">World</span> Forward, One Shipment at a Time.
            </h1>

            <p className="text-lg sm:text-xl text-gray-200 max-w-xl">
              End-to-end freight, parcel, and supply chain solutions with real-time visibility, proactive exception
              management, and a dedicated global support team.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <Link href="/quote">
                <Button
                  size="lg"
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90 text-base sm:text-lg px-8 font-bold uppercase tracking-wide"
                  data-testid="button-cta-get-quote"
                >
                  Get an Instant Quote
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Button>
              </Link>
              <Link href="/tracking">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white/60 text-white hover:bg-white/15 text-base sm:text-lg px-8 font-semibold uppercase tracking-wide"
                  data-testid="button-cta-track"
                >
                  Track a Shipment
                </Button>
              </Link>
            </div>

            {/* Trust badges */}
            <div className="mt-6 flex flex-wrap items-center gap-4 text-xs sm:text-sm text-gray-300">
              <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-black/30 px-3 py-1">
                <ShieldCheck className="h-4 w-4 text-secondary" aria-hidden="true" />
                <span data-testid="badge-certified">ISO 9001 &amp; TAPA Certified</span>
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-black/30 px-3 py-1">
                <CheckCircle2 className="h-4 w-4 text-green-400" aria-hidden="true" />
                <span data-testid="badge-insured">Fully Insured &amp; Bonded</span>
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-black/30 px-3 py-1">
                <Globe className="h-4 w-4 text-blue-300" aria-hidden="true" />
                <span data-testid="badge-coverage">Coverage in 220+ countries</span>
              </div>
            </div>
          </div>

          {/* Hero Right: Tracking + KPIs */}
          <div className="space-y-6">
            <div className="rounded-xl bg-white/95 text-foreground shadow-2xl border border-primary/20 backdrop-blur">
              <div className="p-1.5 text-[10px] font-semibold uppercase tracking-[0.25em] text-center text-muted-foreground border-b bg-muted/60">
                Real-Time Shipment Visibility
              </div>
              <div className="p-4 sm:p-6">
                <TrackingWidget compact />
              </div>
            </div>

            {/* KPI strip */}
            <div className="grid grid-cols-3 gap-3 text-xs sm:text-sm">
              <div className="rounded-lg border border-white/20 bg-black/40 px-3 py-3 text-center">
                <p className="text-lg sm:text-2xl font-heading font-bold text-secondary" data-testid="kpi-ontime">
                  99.8%
                </p>
                <p className="text-[10px] uppercase tracking-wide text-gray-300">On-Time Delivery</p>
              </div>
              <div className="rounded-lg border border-white/20 bg-black/40 px-3 py-3 text-center">
                <p className="text-lg sm:text-2xl font-heading font-bold text-secondary" data-testid="kpi-shipments-daily">
                  1.2M
                </p>
                <p className="text-[10px] uppercase tracking-wide text-gray-300">Shipments / Day</p>
              </div>
              <div className="rounded-lg border border-white/20 bg-black/40 px-3 py-3 text-center">
                <p className="text-lg sm:text-2xl font-heading font-bold text-secondary" data-testid="kpi-sla">
                  24/7
                </p>
                <p className="text-[10px] uppercase tracking-wide text-gray-300">Ops &amp; Support</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Locations teaser section */}
      <section className="py-10 md:py-12 bg-background border-b border-border/50">
        <div className="container mx-auto px-4 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl space-y-2">
            <p className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-primary">
              <MapPinned className="h-3 w-3" /> Global Presence
            </p>
            <h2 className="text-2xl md:text-3xl font-heading font-bold text-primary uppercase">
              A Worldwide Network of UPS Hubs
            </h2>
            <p className="text-sm md:text-base text-muted-foreground" data-testid="text-home-locations-intro">
              Explore a curated map of major UPS hubs and illustrative demo locations across North America, Europe,
              Asia-Pacific, Latin America, the Middle East, and Africa.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <Link href="/locations">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold uppercase tracking-wide"
                data-testid="button-home-view-locations"
              >
                View Locations Map
              </Button>
            </Link>
            <p className="text-[11px] text-muted-foreground max-w-xs">
              Locations shown are demo-only and do not represent every UPS access point.
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-16 md:py-20 bg-muted/40">
        <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] gap-12 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-4 uppercase">
              Built for Complex, Global Supply Chains
            </h2>
            <div className="h-1 w-20 bg-secondary mb-6" aria-hidden="true" />
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-4" data-testid="text-company-overview-primary">
              UPS Logistics is a dedicated logistics partner for enterprises that demand reliability at scale.
              From last-mile parcel delivery to multimodal freight, we manage the flow of goods across oceans,
              borders, and distribution centers with precision.
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed" data-testid="text-company-overview-secondary">
              Our teams combine decades of operational expertise with cutting-edge technology—control towers,
              predictive analytics, and digital twins of your network—to keep your inventory moving and your
              customers informed. Whether you ship once a week or every minute, we design a logistics strategy
              that feels tailor-made.
            </p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
              <div className="rounded-lg bg-background border px-4 py-3">
                <p className="font-heading text-xl text-primary" data-testid="stat-distribution-centers">
                  1,200+
                </p>
                <p className="text-muted-foreground">Distribution centers and cross-docks worldwide.</p>
              </div>
              <div className="rounded-lg bg-background border px-4 py-3">
                <p className="font-heading text-xl text-primary" data-testid="stat-fleet-size">
                  50,000+
                </p>
                <p className="text-muted-foreground">Vehicles, aircraft, and partner carriers.</p>
              </div>
              <div className="rounded-lg bg-background border px-4 py-3">
                <p className="font-heading text-xl text-primary" data-testid="stat-customer-satisfaction">
                  4.9/5
                </p>
                <p className="text-muted-foreground">Average enterprise satisfaction score.</p>
              </div>
            </div>
          </div>

          <div className="rounded-xl border bg-background shadow-sm p-6 space-y-4" aria-label="Executive summary">
            <h3 className="text-xl font-heading font-bold uppercase">Executive Snapshot</h3>
            <p className="text-sm text-muted-foreground">
              We integrate seamlessly with your procurement, inventory, and order management systems to create a
              single, real-time view of your supply chain performance.
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-green-600" aria-hidden="true" />
                <span>Dedicated account teams for strategic planning and continuous optimization.</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-green-600" aria-hidden="true" />
                <span>Sector-specific playbooks for retail, healthcare, technology, automotive, and more.</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-green-600" aria-hidden="true" />
                <span>Global risk monitoring for weather, port congestion, and geopolitical events.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3 uppercase">
              How It Works
            </h2>
            <p className="text-muted-foreground text-base md:text-lg">
              From quote to delivery, every step is orchestrated through a single, unified logistics platform.
            </p>
          </div>

          <ol className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-8" aria-label="How UPS Logistics works">
            {["Request", "Design", "Move", "Optimize"].map((step, index) => (
              <li
                key={step}
                className="relative rounded-xl border bg-card p-6 shadow-sm flex flex-col gap-3"
                data-testid={`card-how-step-${index + 1}`}
              >
                <div className="absolute -top-4 left-4 flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-secondary-foreground text-sm font-bold shadow-md">
                  {index + 1}
                </div>
                <h3 className="mt-2 text-lg font-heading font-bold uppercase">{step}</h3>
                <p className="text-sm text-muted-foreground">
                  {index === 0 &&
                    "Share your shipment details, lanes, and service levels through our digital quote form or via your account team."}
                  {index === 1 &&
                    "We build an optimal routing and capacity plan, aligning carriers, modes, and SLAs with your budget."}
                  {index === 2 &&
                    "Freight moves through our integrated network with real-time tracking, milestones, and exception alerts."}
                  {index === 3 &&
                    "We analyze performance data, surface insights, and continuously refine your logistics strategy."}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Services Section (existing) */}
      <section className="py-16 md:py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-4 uppercase">
              Our Core Logistics Services
            </h2>
            <div className="h-1 w-20 bg-secondary mx-auto mb-6" aria-hidden="true" />
            <p className="text-muted-foreground text-base md:text-lg" data-testid="text-services-intro">
              Comprehensive supply chain management solutions designed to optimize every mile from origin to final
              delivery.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {MOCK_SERVICES.map((service) => (
              <ServiceCard key={service.title} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* Industries We Serve */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3 uppercase">
                Industries We Serve
              </h2>
              <p className="text-muted-foreground max-w-xl text-sm md:text-base">
                Specialized solutions for highly regulated, time-critical, and customer-centric industries.
              </p>
            </div>
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
              Sector-Specific Expertise
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Retail & Ecommerce",
                desc: "Omnichannel fulfillment, returns optimization, and last-mile delivery orchestration.",
              },
              {
                title: "Healthcare & Pharma",
                desc: "Temperature-controlled lanes, chain-of-custody, and regulatory-compliant handling.",
              },
              {
                title: "Technology & Electronics",
                desc: "High-value cargo protection, reverse logistics, and just-in-time supply.",
              },
              {
                title: "Automotive",
                desc: "Inbound-to-manufacturing, sequencing, and dealer distribution networks.",
              },
              {
                title: "Industrial & Heavy",
                desc: "Oversized cargo, project logistics, and remote-site deliveries.",
              },
              {
                title: "SMB & Startups",
                desc: "Flexible contracts, simple onboarding, and scalable solutions as you grow.",
              },
            ].map((item, index) => (
              <article
                key={item.title}
                className="rounded-xl border bg-card p-6 shadow-sm hover:shadow-lg transition-shadow"
                data-testid={`card-industry-${index}`}
              >
                <h3 className="text-lg font-heading font-bold mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Technology & Real-Time Visibility */}
      <section className="py-16 md:py-20 bg-zinc-900 text-white">
        <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.25em] text-secondary">
              <Radar className="h-3 w-3" aria-hidden="true" />
              Control Tower Technology
            </p>
            <h2 className="mt-4 text-3xl md:text-4xl font-heading font-bold uppercase">
              Technology that Sees Every Mile
            </h2>
            <p className="mt-4 text-sm md:text-base text-gray-300" data-testid="text-technology-overview">
              Our digital control towers combine IoT sensors, carrier integrations, and predictive analytics to give
              you a live view of every shipment, lane, and node in your network.
            </p>

            <ul className="mt-6 space-y-3 text-sm text-gray-200">
              <li className="flex gap-2">
                <Cpu className="mt-0.5 h-4 w-4 text-secondary" aria-hidden="true" />
                <span>AI-powered ETA predictions with weather, traffic, and port congestion signals.</span>
              </li>
              <li className="flex gap-2">
                <LineChart className="mt-0.5 h-4 w-4 text-secondary" aria-hidden="true" />
                <span>Exception dashboards and heatmaps for at-risk shipments.</span>
              </li>
              <li className="flex gap-2">
                <Globe className="mt-0.5 h-4 w-4 text-secondary" aria-hidden="true" />
                <span>Single pane of glass for multi-carrier, multimodal operations.</span>
              </li>
            </ul>
          </div>

          <div className="rounded-2xl border border-white/15 bg-gradient-to-br from-zinc-900 via-zinc-950 to-zinc-900 p-6 shadow-2xl">
            <div className="grid grid-cols-2 gap-4 text-xs sm:text-sm">
              <div className="rounded-lg bg-black/40 border border-white/10 p-4">
                <p className="text-gray-400 mb-1">Live Shipments</p>
                <p className="text-2xl font-heading font-bold text-secondary" data-testid="metric-live-shipments">
                  48,213
                </p>
                <p className="text-[11px] text-emerald-300">+1.4% vs. yesterday</p>
              </div>
              <div className="rounded-lg bg-black/40 border border-white/10 p-4">
                <p className="text-gray-400 mb-1">On-Time Performance</p>
                <p className="text-2xl font-heading font-bold text-secondary" data-testid="metric-otp">
                  99.8%
                </p>
                <p className="text-[11px] text-emerald-300">SLA: 98.0%</p>
              </div>
              <div className="rounded-lg bg-black/40 border border-white/10 p-4">
                <p className="text-gray-400 mb-1">Exceptions Today</p>
                <p className="text-2xl font-heading font-bold text-secondary" data-testid="metric-exceptions">
                  134
                </p>
                <p className="text-[11px] text-amber-300">All being actively managed</p>
              </div>
              <div className="rounded-lg bg-black/40 border border-white/10 p-4">
                <p className="text-gray-400 mb-1">Customer Satisfaction</p>
                <p className="text-2xl font-heading font-bold text-secondary" data-testid="metric-csat">
                  4.9/5
                </p>
                <p className="text-[11px] text-emerald-300">Rolling 90-day average</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Global Network & Coverage + Sustainability */}
      <section className="py-16 md:py-20 bg-muted/40">
        <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] gap-12 items-stretch">
          {/* Global network */}
          <div className="space-y-6">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary uppercase">
              Global Network &amp; Coverage
            </h2>
            <p className="text-sm md:text-base text-muted-foreground" data-testid="text-global-network">
              Strategic hubs near major ports, airports, and manufacturing centers ensure your products are always
              within reach of your customers.
            </p>
            <div className="relative mt-4 h-56 rounded-xl border bg-slate-200 overflow-hidden" aria-label="Global coverage map placeholder">
              <div
                className="absolute inset-0 opacity-80"
                style={{
                  backgroundImage: "radial-gradient(#cbd5e1 1px, transparent 1px)",
                  backgroundSize: "20px 20px",
                }}
              />
              <div className="absolute inset-6 border border-dashed border-slate-400 rounded-xl" aria-hidden="true" />
              <div className="relative z-10 flex h-full flex-col items-center justify-center text-center px-4">
                <MapPin className="h-10 w-10 text-primary mb-3" aria-hidden="true" />
                <p className="text-sm font-semibold text-slate-800">Interactive network map coming soon</p>
                <p className="text-xs text-slate-600 max-w-sm">
                  Visualize lanes, hubs, and live shipment density for your global operations.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-xs md:text-sm">
              <div className="rounded-lg bg-background border px-4 py-3">
                <p className="font-heading text-lg text-primary">220+</p>
                <p className="text-muted-foreground">Countries &amp; territories served.</p>
              </div>
              <div className="rounded-lg bg-background border px-4 py-3">
                <p className="font-heading text-lg text-primary">6</p>
                <p className="text-muted-foreground">Continental control towers.</p>
              </div>
            </div>
          </div>

          {/* Sustainability */}
          <aside className="rounded-2xl bg-emerald-950 text-emerald-50 border border-emerald-700/60 p-6 flex flex-col gap-4" aria-label="Sustainability & green logistics">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-600/20">
                <Leaf className="h-5 w-5 text-emerald-300" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-lg font-heading font-bold uppercase">Sustainability at Scale</h3>
                <p className="text-xs text-emerald-200">Carbon-aware routing and green lane design.</p>
              </div>
            </div>
            <p className="text-sm text-emerald-100" data-testid="text-sustainability">
              Sustainability is embedded in every routing decision we make, from vehicle selection to consolidation
              strategies.
            </p>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-300" aria-hidden="true" />
                <span>Carbon-neutral options available on all major trade lanes.</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-300" aria-hidden="true" />
                <span>Fleet modernization with EVs and alternative fuels where infrastructure allows.</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-4 w-4 text-emerald-300" aria-hidden="true" />
                <span>Granular emissions reporting down to shipment, lane, and customer level.</span>
              </li>
            </ul>
          </aside>
        </div>
      </section>

      {/* Case Studies */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3 uppercase">
                Proven Customer Outcomes
              </h2>
              <p className="text-muted-foreground max-w-xl text-sm md:text-base" data-testid="text-case-studies-intro">
                Real stories from organizations that transformed their logistics with UPS Logistics.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                company: "Global Fashion Retailer",
                impact: "18% lower transportation costs",
                summary:
                  "Consolidated regional carriers into a single global program, unlocking better capacity and rate visibility.",
              },
              {
                company: "Biopharma Leader",
                impact: "99.99% cold-chain integrity",
                summary:
                  "Designed validated temperature-controlled lanes with real-time monitoring and audited chain-of-custody.",
              },
              {
                company: "Industrial Manufacturer",
                impact: "35% faster lead times",
                summary:
                  "Reconfigured inbound-to-manufacturing network with cross-dock optimization and dynamic routing.",
              },
            ].map((cs, index) => (
              <article
                key={cs.company}
                className="rounded-xl border bg-card p-6 shadow-sm flex flex-col gap-3"
                data-testid={`card-case-study-${index}`}
              >
                <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Case Study</p>
                <h3 className="text-lg font-heading font-bold">{cs.company}</h3>
                <p className="text-sm font-semibold text-primary">{cs.impact}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{cs.summary}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-4 uppercase">
              What Our Customers Say
            </h2>
            <p className="text-muted-foreground text-sm md:text-base">
              Logistics leaders around the world trust UPS Logistics to deliver every single day.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Maria Gonzalez",
                title: "VP Supply Chain, Global Retail Brand",
                quote:
                  "UPS Logistics became an extension of our team. We gained visibility we never thought possible across hundreds of stores.",
              },
              {
                name: "Dr. Liam Patel",
                title: "Director of Logistics, Biopharma Company",
                quote:
                  "Their cold-chain expertise and compliance rigor allowed us to expand into new markets with confidence.",
              },
              {
                name: "James Carter",
                title: "COO, Industrial Manufacturer",
                quote:
                  "We cut lead times and inventory buffers while actually improving on-time delivery—a rare combination.",
              },
            ].map((t, index) => (
              <figure
                key={t.name}
                className="rounded-xl bg-card border shadow-sm p-6 flex flex-col justify-between min-h-[220px]"
                data-testid={`card-testimonial-${index}`}
              >
                <p className="text-sm text-muted-foreground mb-4">“{t.quote}”</p>
                <figcaption className="text-sm">
                  <p className="font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.title}</p>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-20 bg-background">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3 uppercase">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground text-sm md:text-base">
              Have more questions? Our team is here 24/7 to help you design the right logistics program.
            </p>
          </div>

          <Accordion type="single" collapsible className="w-full" data-testid="accordion-faq">
            {[
              {
                q: "What modes of transportation do you offer?",
                a: "We offer air, ocean, road, rail, and multimodal solutions, tailored to your service-level and budget requirements.",
              },
              {
                q: "Can you integrate with our existing systems?",
                a: "Yes. Our platform integrates with major ERPs, TMS, WMS, and ecommerce systems using industry-standard APIs.",
              },
              {
                q: "Do you support temperature-controlled and hazardous materials?",
                a: "We maintain specialized networks and certified partners for cold-chain and hazardous materials in compliance with local regulations.",
              },
              {
                q: "Is there a minimum volume requirement?",
                a: "We work with both high-volume enterprises and fast-growing mid-market shippers. Programs are right-sized to your profile.",
              },
              {
                q: "How quickly can we go live?",
                a: "Typical onboarding ranges from 412 weeks depending on complexity, integrations, and geographic scope.",
              },
            ].map((item, index) => (
              <AccordionItem
                key={item.q}
                value={`item-${index}`}
                data-testid={`faq-item-${index}`}
              >
                <AccordionTrigger className="text-left text-sm md:text-base font-semibold">
                  {item.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Blog / News Preview */}
      <section className="py-16 md:py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <h2 className="text-3xl md:text-4xl font-heading font-bold text-primary mb-3 uppercase">
                Insights &amp; Perspectives
              </h2>
              <p className="text-muted-foreground max-w-xl text-sm md:text-base">
                Stay ahead of disruptions, regulations, and innovations shaping the future of logistics.
              </p>
            </div>
            <Link href="/about">
              <button
                className="text-xs font-semibold uppercase tracking-[0.18em] text-primary hover:text-primary/80"
                data-testid="link-view-all-insights"
              >
                View company insights
              </button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Designing Resilient Supply Chains in Volatile Markets",
                tag: "Strategy",
                date: "Nov 12, 2024",
              },
              {
                title: "How Real-Time Visibility Reduces Inventory Buffers",
                tag: "Technology",
                date: "Oct 04, 2024",
              },
              {
                title: "Building Low-Carbon Logistics Without Sacrificing Speed",
                tag: "Sustainability",
                date: "Sep 19, 2024",
              },
            ].map((post, index) => (
              <article
                key={post.title}
                className="rounded-xl bg-card border shadow-sm overflow-hidden flex flex-col"
                data-testid={`card-blog-${index}`}
              >
                <div className="h-24 bg-gradient-to-r from-primary/80 via-primary to-secondary/70" aria-hidden="true" />
                <div className="flex-1 p-5 flex flex-col gap-2">
                  <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                    <span>{post.tag}</span>
                    <span>{post.date}</span>
                  </div>
                  <h3 className="text-sm md:text-base font-heading font-bold leading-snug">
                    {post.title}
                  </h3>
                  <button
                    className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-primary hover:text-primary/80"
                    data-testid={`button-read-article-${index}`}
                  >
                    Read Article
                    <ArrowRight className="h-3 w-3" aria-hidden="true" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Strong CTA Before Footer */}
      <section className="py-16 md:py-20 bg-zinc-900 text-white">
        <div className="container mx-auto px-4">
          <div className="rounded-2xl border border-secondary/40 bg-gradient-to-r from-zinc-900 via-zinc-950 to-zinc-900 px-6 py-10 md:px-10 md:py-12 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="max-w-xl">
              <p className="text-xs uppercase tracking-[0.25em] text-secondary mb-2">Let&apos;s Move Forward</p>
              <h2 className="text-3xl md:text-4xl font-heading font-bold mb-3 uppercase">
                Ready to Design Your Next-Generation Logistics Program?
              </h2>
              <p className="text-sm md:text-base text-gray-300" data-testid="text-cta-before-footer">
                Share your lanes, volumes, and goals—we&apos;ll return with a tailored proposal and implementation
                roadmap.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 min-w-[220px] justify-end">
              <Link href="/quote">
                <Button
                  size="lg"
                  className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold uppercase tracking-wide w-full sm:w-auto"
                  data-testid="button-cta-design-program"
                >
                  Request Custom Quote
                </Button>
              </Link>
              <Link href="/contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/60 text-white hover:bg-white/10 font-semibold uppercase tracking-wide w-full sm:w-auto"
                  data-testid="button-cta-talk-expert"
                >
                  Talk to an Expert
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
