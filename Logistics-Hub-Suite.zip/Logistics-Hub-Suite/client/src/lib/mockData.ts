
export interface ShipmentEvent {
  date: string;
  status: string;
  location: string;
}

export interface Shipment {
  id: string;
  trackingNumber: string;
  status: "In Transit" | "Delivered" | "Exception" | "Pending";
  origin: string;
  destination: string;
  estimatedDelivery: string;
  service: string;
  weight: string;
  events: ShipmentEvent[];
}

export const MOCK_SHIPMENTS: Shipment[] = [
  {
    id: "1",
    trackingNumber: "UPS123456789",
    status: "In Transit",
    origin: "New York, NY",
    destination: "London, UK",
    estimatedDelivery: "2024-11-25",
    service: "Express Air",
    weight: "15.4 kg",
    events: [
      { date: "2024-11-22 08:30", status: "Departed Facility", location: "JFK Airport, NY" },
      { date: "2024-11-21 18:00", status: "Arrived at Facility", location: "Queens, NY" },
      { date: "2024-11-21 14:00", status: "Pickup Scan", location: "Manhattan, NY" },
    ]
  },
  {
    id: "2",
    trackingNumber: "UPS987654321",
    status: "Delivered",
    origin: "Shanghai, CN",
    destination: "Los Angeles, CA",
    estimatedDelivery: "2024-11-20",
    service: "Ocean Freight",
    weight: "4500 kg",
    events: [
      { date: "2024-11-20 10:00", status: "Delivered", location: "Los Angeles, CA" },
      { date: "2024-11-19 09:00", status: "Out for Delivery", location: "Los Angeles, CA" },
      { date: "2024-11-15 12:00", status: "Customs Cleared", location: "Port of LA" },
    ]
  },
  {
    id: "3",
    trackingNumber: "UPS555555555",
    status: "Exception",
    origin: "Berlin, DE",
    destination: "Paris, FR",
    estimatedDelivery: "Unknown",
    service: "Standard Truck",
    weight: "2.5 kg",
    events: [
      { date: "2024-11-21 10:00", status: "Delay: Weather Conditions", location: "Munich, DE" },
      { date: "2024-11-20 15:00", status: "In Transit", location: "Berlin, DE" },
    ]
  }
];

export interface ServiceItem {
  title: string;
  description: string;
  icon: "Plane" | "Ship" | "Truck" | "Warehouse";
}

export const MOCK_SERVICES: ServiceItem[] = [
  {
    title: "Air Freight",
    description: "Fastest global delivery for time-sensitive cargo.",
    icon: "Plane"
  },
  {
    title: "Ocean Freight",
    description: "Cost-effective solutions for large volume shipments.",
    icon: "Ship"
  },
  {
    title: "Ground Shipping",
    description: "Reliable nationwide trucking and rail networks.",
    icon: "Truck"
  },
  {
    title: "Warehousing",
    description: "Secure storage and inventory management solutions.",
    icon: "Warehouse"
  }
];
