export type RegionKey =
  | "global"
  | "north-america"
  | "europe"
  | "asia-pacific"
  | "latin-america"
  | "middle-east"
  | "africa";

export interface LocationPoint {
  id: string;
  name: string;
  city: string;
  country: string;
  region: RegionKey;
  lat: number;
  lng: number;
}

// Seed dataset: illustrative only
export const SEEDED_LOCATIONS: LocationPoint[] = [
  {
    id: "atl-hub",
    name: "UPS Global Air Hub (Demo)",
    city: "Atlanta, GA",
    country: "United States",
    region: "north-america",
    lat: 33.6407,
    lng: -84.4277,
  },
  {
    id: "louisville-hub",
    name: "UPS Worldport (Demo)",
    city: "Louisville, KY",
    country: "United States",
    region: "north-america",
    lat: 38.1744,
    lng: -85.736,
  },
  {
    id: "toronto-hub",
    name: "UPS Canada Hub (Demo)",
    city: "Toronto",
    country: "Canada",
    region: "north-america",
    lat: 43.6777,
    lng: -79.6248,
  },
  {
    id: "koln-hub",
    name: "UPS Europe Air Hub (Demo)",
    city: "Cologne",
    country: "Germany",
    region: "europe",
    lat: 50.8659,
    lng: 7.1427,
  },
  {
    id: "london-hub",
    name: "UPS London Hub (Demo)",
    city: "London",
    country: "United Kingdom",
    region: "europe",
    lat: 51.47,
    lng: -0.4543,
  },
  {
    id: "paris-hub",
    name: "UPS Paris Hub (Demo)",
    city: "Paris",
    country: "France",
    region: "europe",
    lat: 49.0097,
    lng: 2.5479,
  },
  {
    id: "shanghai-hub",
    name: "UPS Asia-Pacific Hub (Demo)",
    city: "Shanghai",
    country: "China",
    region: "asia-pacific",
    lat: 31.1434,
    lng: 121.8052,
  },
  {
    id: "hongkong-hub",
    name: "UPS Hong Kong Hub (Demo)",
    city: "Hong Kong",
    country: "China",
    region: "asia-pacific",
    lat: 22.308,
    lng: 113.9185,
  },
  {
    id: "sydney-hub",
    name: "UPS Sydney Gateway (Demo)",
    city: "Sydney",
    country: "Australia",
    region: "asia-pacific",
    lat: -33.9399,
    lng: 151.1753,
  },
  {
    id: "dubai-hub",
    name: "UPS Middle East Hub (Demo)",
    city: "Dubai",
    country: "United Arab Emirates",
    region: "middle-east",
    lat: 25.2532,
    lng: 55.3657,
  },
  {
    id: "johannesburg-hub",
    name: "UPS Africa Hub (Demo)",
    city: "Johannesburg",
    country: "South Africa",
    region: "africa",
    lat: -26.1392,
    lng: 28.246,
  },
  {
    id: "sao-paulo-hub",
    name: "UPS Latin America Hub (Demo)",
    city: "São Paulo",
    country: "Brazil",
    region: "latin-america",
    lat: -23.4356,
    lng: -46.4731,
  },
];

export const REGION_CONFIG: Record<RegionKey, { label: string; center: [number, number]; zoom: number }> = {
  global: {
    label: "Global View",
    center: [20, 0],
    zoom: 2,
  },
  "north-america": {
    label: "North America",
    center: [39, -98],
    zoom: 3,
  },
  europe: {
    label: "Europe",
    center: [54, 15],
    zoom: 4,
  },
  "asia-pacific": {
    label: "Asia-Pacific",
    center: [20, 110],
    zoom: 3,
  },
  "latin-america": {
    label: "Latin America",
    center: [-15, -60],
    zoom: 3,
  },
  "middle-east": {
    label: "Middle East",
    center: [25, 45],
    zoom: 4,
  },
  africa: {
    label: "Africa",
    center: [3, 21],
    zoom: 3,
  },
};
