import { Link, useLocation } from "wouter";
import { Package, Menu, X, User, Phone, Globe, MapPinned } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/tracking", label: "Tracking" },
    { href: "/quote", label: "Get a Quote" },
    { href: "/locations", label: "Locations" },
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Top Bar - Very Corporate */}
      <div className="bg-primary text-primary-foreground py-2 px-4 text-xs font-medium hidden md:flex justify-between items-center">
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><Globe className="h-3 w-3" /> Global Logistics Partner</span>
          <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> 1-800-UPS-FULL</span>
        </div>
        <div className="flex gap-4">
          <Link href="/admin" className="hover:text-secondary transition-colors">Employee Login</Link>
          <Link href="/support" className="hover:text-secondary transition-colors">Support Center</Link>
        </div>
      </div>

      {/* Main Navbar */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
        <div className="container mx-auto px-4 h-20 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="bg-primary text-primary-foreground p-2 rounded-sm group-hover:bg-secondary group-hover:text-secondary-foreground transition-colors">
              <Package className="h-6 w-6" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="font-heading font-bold text-xl uppercase tracking-tight text-primary">UPS</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">Logistics</span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                className={`text-sm font-medium transition-colors hover:text-primary uppercase tracking-wide ${location === link.href ? "text-primary font-bold border-b-2 border-secondary" : "text-muted-foreground"}`}
                data-testid={`link-nav-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-4">
            <Link href="/login">
              <Button variant="ghost" size="sm" className="gap-2" data-testid="button-login-header">
                <User className="h-4 w-4" /> Login
              </Button>
            </Link>
            <Link href="/quote">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold uppercase tracking-wide" data-testid="button-get-started-header">
                Get Started
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? "Close navigation" : "Open navigation"}
            data-testid="button-toggle-mobile-nav"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t bg-background p-4 flex flex-col gap-4 animate-in slide-in-from-top-5">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`text-lg font-medium py-2 ${location === link.href ? "text-primary" : "text-muted-foreground"}`}
                data-testid={`link-nav-mobile-${link.label.toLowerCase().replace(/\s+/g, "-")}`}
              >
                {link.label}
              </Link>
            ))}
            <div className="flex flex-col gap-2 mt-4 pt-4 border-t">
               <Link href="/login" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="outline" className="w-full justify-start gap-2" data-testid="button-mobile-login"><User className="h-4 w-4"/> Customer Login</Button>
              </Link>
              <Link href="/quote" onClick={() => setMobileMenuOpen(false)}>
                <Button className="w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold" data-testid="button-mobile-quote">Request Quote</Button>
              </Link>
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-zinc-900 text-zinc-400 py-12 border-t border-zinc-800">
        <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
             <div className="flex items-center gap-2">
                <div className="bg-primary text-primary-foreground p-1.5 rounded-sm">
                  <Package className="h-5 w-5" />
                </div>
                <span className="font-heading font-bold text-lg text-white uppercase">UPS Logistics</span>
              </div>
            <p className="text-sm">
              Global supply chain solutions tailored to your business needs. Reliable, fast, and secure shipping worldwide.
            </p>
            <p className="text-[11px] text-zinc-500" data-testid="text-footer-disclaimer">
              This site is a design prototype for demonstration purposes only and is <span className="font-semibold">not affiliated with or endorsed by United Parcel Service (UPS)</span>.
            </p>
          </div>
          
          <div>
            <h4 className="text-white font-heading font-bold uppercase mb-4">Services</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/services" className="hover:text-secondary" data-testid="link-footer-air">Air Freight</Link></li>
              <li><Link href="/services" className="hover:text-secondary" data-testid="link-footer-ocean">Ocean Freight</Link></li>
              <li><Link href="/services" className="hover:text-secondary" data-testid="link-footer-ground">Ground Shipping</Link></li>
              <li><Link href="/services" className="hover:text-secondary" data-testid="link-footer-warehousing">Warehousing</Link></li>
            </ul>
          </div>

          <div>
             <h4 className="text-white font-heading font-bold uppercase mb-4">Support</h4>
             <ul className="space-y-2 text-sm">
              <li><Link href="/tracking" className="hover:text-secondary" data-testid="link-footer-tracking">Track a Shipment</Link></li>
              <li><Link href="/quote" className="hover:text-secondary" data-testid="link-footer-quote">Get a Quote</Link></li>
              <li><Link href="/locations" className="hover:text-secondary" data-testid="link-footer-locations"><span className="inline-flex items-center gap-1"><MapPinned className="h-3 w-3" /> Locations</span></Link></li>
              <li><Link href="/about" className="hover:text-secondary" data-testid="link-footer-about">About Company</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-heading font-bold uppercase mb-4">Newsletter</h4>
            <p className="text-sm mb-4">Subscribe for logistics insights and company news.</p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Email address"
                className="bg-zinc-800 border-none rounded px-3 py-2 text-sm w-full text-white focus:ring-1 focus:ring-secondary"
                data-testid="input-newsletter-email"
              />
              <Button size="sm" className="bg-secondary text-secondary-foreground hover:bg-secondary/90 font-bold" data-testid="button-newsletter-go">GO</Button>
            </div>
          </div>
        </div>
        <div className="container mx-auto px-4 mt-12 pt-8 border-t border-zinc-800 text-xs text-center md:text-left flex flex-col md:flex-row justify-between items-center gap-3">
          <p>&copy; 2024 UPS Logistics. All rights reserved.</p>
          <div className="flex flex-wrap gap-4 items-center justify-center md:justify-end">
            <Link href="/readme" className="hover:text-white" data-testid="link-footer-system-info">System Info</Link>
            <a href="#" className="hover:text-white" data-testid="link-footer-privacy">Privacy Policy</a>
            <a href="#" className="hover:text-white" data-testid="link-footer-terms">Terms of Service</a>
            <a href="#" className="hover:text-white" data-testid="link-footer-sitemap">Sitemap</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
