import { useMemo, useRef, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from "react-leaflet";
import type { LatLngBounds } from "leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { SEEDED_LOCATIONS, REGION_CONFIG, RegionKey, LocationPoint } from "@/lib/locations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation2, Search, LocateFixed, Info } from "lucide-react";

// Fix default icon paths for Leaflet in bundlers
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(delete (L.Icon.Default.prototype as any)._getIconUrl);
(L.Icon.Default as any).mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

interface BoundsCacheEntry {
  timestamp: number;
  locations: LocationPoint[];
}

const OVERPASS_ENDPOINT = "https://overpass-api.de/api/interpreter";
const CACHE_TTL_MS = 1000 * 60 * 5; // 5 minutes
const MIN_FETCH_INTERVAL_MS = 1000 * 20; // 20 seconds between remote calls

function boundsKey(bounds: LatLngBounds | null): string | null {
  if (!bounds) return null;
  const sw = bounds.getSouthWest();
  const ne = bounds.getNorthEast();
  return [
    sw.lat.toFixed(2),
    sw.lng.toFixed(2),
    ne.lat.toFixed(2),
    ne.lng.toFixed(2),
  ].join(":");
}

function MapEventsHandler({
  onBoundsChange,
}: {
  onBoundsChange: (bounds: LatLngBounds) => void;
}) {
  useMapEvents({
    moveend: (event) => {
      onBoundsChange(event.target.getBounds());
    },
  });
  return null;
}

export function LocationsMap() {
  const [region, setRegion] = useState<RegionKey>("global");
  const [search, setSearch] = useState("");
  const [useLiveData, setUseLiveData] = useState(false);
  const [liveLocations, setLiveLocations] = useState<LocationPoint[]>([]);
  const [status, setStatus] = useState<string>(
    "Showing curated demo locations. Enable live lookup to fetch nearby UPS points of interest.",
  );
  const cacheRef = useRef<Record<string, BoundsCacheEntry>>({});
  const lastFetchRef = useRef<number>(0);
  const [mapBounds, setMapBounds] = useState<LatLngBounds | null>(null);

  const activeLocations = useMemo(() => {
    const base = useLiveData && liveLocations.length > 0 ? liveLocations : SEEDED_LOCATIONS;

    const byRegion = region === "global" ? base : base.filter((l) => l.region === region);

    if (!search.trim()) return byRegion;
    const term = search.toLowerCase();
    return byRegion.filter((loc) => {
      return (
        loc.name.toLowerCase().includes(term) ||
        loc.city.toLowerCase().includes(term) ||
        loc.country.toLowerCase().includes(term)
      );
    });
  }, [region, search, useLiveData, liveLocations]);

  async function fetchLiveLocations(bounds: LatLngBounds) {
    if (!useLiveData) return;

    const key = boundsKey(bounds);
    if (!key) return;

    const now = Date.now();
    const last = lastFetchRef.current;
    if (now - last < MIN_FETCH_INTERVAL_MS) {
      return;
    }

    const existing = cacheRef.current[key];
    if (existing && now - existing.timestamp < CACHE_TTL_MS) {
      setLiveLocations(existing.locations);
      setStatus("Using cached live locations for this area.");
      lastFetchRef.current = now;
      return;
    }

    try {
      lastFetchRef.current = now;
      setStatus("Looking up nearby UPS locations (beta)...");

      const sw = bounds.getSouthWest();
      const ne = bounds.getNorthEast();

      const query = `
        [out:json][timeout:25];
        (
          node["name"~"UPS",i](${sw.lat},${sw.lng},${ne.lat},${ne.lng});
          way["name"~"UPS",i](${sw.lat},${sw.lng},${ne.lat},${ne.lng});
          relation["name"~"UPS",i](${sw.lat},${sw.lng},${ne.lat},${ne.lng});
        );
        out center 40;
      `;

      const res = await fetch(OVERPASS_ENDPOINT, {
        method: "POST",
        body: query,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        },
      });

      if (!res.ok) {
        throw new Error(`Overpass error: ${res.status}`);
      }

      const json = await res.json();
      const elements = Array.isArray(json.elements) ? json.elements : [];

      const mapped: LocationPoint[] = elements
        .map((el: any, idx: number) => {
          const center = el.center ?? { lat: el.lat, lon: el.lon };
          if (!center?.lat || !center?.lon) return null;

          const name: string = el.tags?.name ?? "UPS Location";
          const city = el.tags?.["addr:city"] ?? "City";
          const country = el.tags?.["addr:country"] ?? "Country";

          return {
            id: `live-${el.id}-${idx}`,
            name: `${name} (Live)`,
            city,
            country,
            lat: center.lat,
            lng: center.lon,
            region: "global" as RegionKey,
          } satisfies LocationPoint;
        })
        .filter(Boolean) as LocationPoint[];

      if (mapped.length === 0) {
        setStatus("No additional live locations found in this view. Showing demo hubs.");
        return;
      }

      cacheRef.current[key] = {
        timestamp: now,
        locations: mapped,
      };
      setLiveLocations(mapped);
      setStatus("Showing live UPS points of interest from OpenStreetMap (beta).");
    } catch (err) {
      console.error(err);
      setStatus("Could not load live locations. Showing demo hubs only.");
    }
  }

  const regionButtons: { key: RegionKey; label: string }[] = [
    "global",
    "north-america",
    "europe",
    "asia-pacific",
    "latin-america",
    "middle-east",
    "africa",
  ].map((key) => ({ key: key as RegionKey, label: REGION_CONFIG[key as RegionKey].label }));

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      setStatus("Geolocation is not available in this browser.");
      return;
    }
    setStatus("Locating you...");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const pseudoBounds = L.latLngBounds(
          [latitude - 0.5, longitude - 0.5],
          [latitude + 0.5, longitude + 0.5],
        );
        setMapBounds(pseudoBounds);
        setStatus("Centered on your approximate location (demo).");
      },
      () => {
        setStatus("Unable to access your location. Please check browser permissions.");
      },
    );
  };

  const initialRegion = REGION_CONFIG[region];

  return (
    <section className="space-y-4" aria-label="UPS global locations map">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="space-y-1">
          <h2 className="text-xl font-heading font-bold uppercase text-primary">UPS Locations Worldwide</h2>
          <p className="text-xs text-muted-foreground max-w-xl">
            Locations shown are <span className="font-semibold">illustrative demo hubs only</span> and may not
            represent the full real-world UPS network.
          </p>
        </div>
        <div className="flex flex-wrap gap-2 items-center justify-start md:justify-end">
          <div className="relative w-full sm:w-56">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              data-testid="input-location-search"
              className="pl-8 pr-2 h-9 text-xs"
              placeholder="Search city, country, or hub..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-1 h-9 text-xs"
            onClick={handleUseMyLocation}
            data-testid="button-use-my-location"
          >
            <LocateFixed className="h-3 w-3" /> Use my location
          </Button>
        </div>
      </div>

      {/* Region filters */}
      <div className="flex flex-wrap gap-2" aria-label="Region filters">
        {regionButtons.map((r) => (
          <Button
            key={r.key}
            type="button"
            variant={region === r.key ? "default" : "outline"}
            size="sm"
            className="text-xs"
            onClick={() => setRegion(r.key)}
            data-testid={`button-region-${r.key}`}
          >
            {r.label}
          </Button>
        ))}
        <button
          type="button"
          onClick={() => setUseLiveData((prev) => !prev)}
          className={`ml-auto inline-flex items-center gap-1 rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${
            useLiveData
              ? "border-emerald-500 bg-emerald-50 text-emerald-800"
              : "border-muted-foreground/30 text-muted-foreground"
          }`}
          aria-pressed={useLiveData}
          data-testid="toggle-live-locations"
        >
          <Info className="h-3 w-3" /> Live lookup (beta)
        </button>
      </div>

      <div className="grid gap-3 md:grid-cols-[minmax(0,3fr)_minmax(0,1.4fr)] items-start">
        {/* Map */}
        <div className="h-[360px] md:h-[420px] rounded-xl overflow-hidden border bg-muted relative">
          <MapContainer
            center={initialRegion.center}
            zoom={initialRegion.zoom}
            className="h-full w-full"
            scrollWheelZoom
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {activeLocations.map((location) => (
              <Marker
                key={location.id}
                position={[location.lat, location.lng]}
              >
                <Popup>
                  <div className="space-y-1 text-xs">
                    <p className="font-semibold" data-testid={`popup-name-${location.id}`}>
                      {location.name}
                    </p>
                    <p className="text-muted-foreground" data-testid={`popup-city-${location.id}`}>
                      {location.city}, {location.country}
                    </p>
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${location.lat},${location.lng}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 text-primary hover:underline mt-1"
                      data-testid={`link-directions-${location.id}`}
                    >
                      <Navigation2 className="h-3 w-3" /> Get Directions
                    </a>
                  </div>
                </Popup>
              </Marker>
            ))}

            <MapEventsHandler
              onBoundsChange={(b) => {
                setMapBounds(b);
                fetchLiveLocations(b);
              }}
            />
          </MapContainer>
        </div>

        {/* Legend / list */}
        <aside className="space-y-3 text-xs" aria-label="Map legend and visible locations">
          <div className="rounded-lg border bg-card p-3 flex items-start gap-2">
            <MapPin className="mt-0.5 h-4 w-4 text-primary" aria-hidden="true" />
            <p className="text-muted-foreground" data-testid="text-locations-note">
              Markers represent major UPS hubs and flagship locations for demo purposes. They do not cover every
              individual UPS access point worldwide.
            </p>
          </div>

          <div className="flex flex-wrap gap-2 items-center">
            <span className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Legend</span>
            <Badge className="bg-primary/10 text-primary border-primary/30" data-testid="badge-demo-hubs">
              Demo hub
            </Badge>
            <Badge className="bg-emerald-50 text-emerald-800 border-emerald-300" data-testid="badge-live-poi">
              Live OSM POI
            </Badge>
          </div>

          <div className="rounded-lg border bg-card p-3 max-h-56 overflow-y-auto" aria-label="Visible locations list">
            <p className="mb-2 text-[11px] uppercase tracking-[0.18em] text-muted-foreground">
              Visible Locations ({activeLocations.length})
            </p>
            {activeLocations.length === 0 ? (
              <p className="text-xs text-muted-foreground">No locations match your filters in this view.</p>
            ) : (
              <ul className="space-y-1">
                {activeLocations.map((l) => (
                  <li key={l.id} className="flex items-center gap-2 text-xs">
                    <span className="h-2 w-2 rounded-full bg-primary" aria-hidden="true" />
                    <span>
                      <span className="font-semibold">{l.city}</span>, {l.country}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <p className="text-[11px] text-muted-foreground" data-testid="text-locations-status">
            {status}
          </p>
        </aside>
      </div>
    </section>
  );
}
