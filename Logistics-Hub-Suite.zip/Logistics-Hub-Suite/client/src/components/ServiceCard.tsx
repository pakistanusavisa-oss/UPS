import { Plane, Ship, Truck, Warehouse, Package, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const iconMap = {
  Plane,
  Ship,
  Truck,
  Warehouse
};

interface ServiceCardProps {
  title: string;
  description: string;
  icon: keyof typeof iconMap;
}

export function ServiceCard({ title, description, icon }: ServiceCardProps) {
  const Icon = iconMap[icon] || Package;

  return (
    <div className="group relative bg-card hover:bg-primary transition-colors duration-300 p-8 rounded-lg border border-border shadow-sm hover:shadow-xl overflow-hidden">
      <div className="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-secondary/10 rounded-full group-hover:bg-white/10 transition-colors"></div>
      
      <div className="relative z-10">
        <div className="h-12 w-12 bg-primary/10 text-primary group-hover:bg-white group-hover:text-primary rounded-md flex items-center justify-center mb-6 transition-colors">
          <Icon className="h-6 w-6" />
        </div>
        
        <h3 className="text-xl font-heading font-bold mb-3 text-foreground group-hover:text-white transition-colors">
          {title}
        </h3>
        
        <p className="text-muted-foreground group-hover:text-white/80 mb-6 transition-colors leading-relaxed">
          {description}
        </p>
        
        <div className="flex items-center text-primary font-bold text-sm uppercase tracking-wide group-hover:text-secondary transition-colors cursor-pointer">
          Learn More <ArrowRight className="ml-2 h-4 w-4" />
        </div>
      </div>
    </div>
  );
}
