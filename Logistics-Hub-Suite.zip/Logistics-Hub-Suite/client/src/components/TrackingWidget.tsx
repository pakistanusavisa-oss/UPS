import { useState } from "react";
import { Search, MapPin, Calendar, CheckCircle, Truck, AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MOCK_SHIPMENTS, Shipment } from "@/lib/mockData";
import { motion, AnimatePresence } from "framer-motion";

export function TrackingWidget({ compact = false }: { compact?: boolean }) {
  const [trackingId, setTrackingId] = useState("");
  const [result, setResult] = useState<Shipment | null>(null);
  const [error, setError] = useState("");
  const [searched, setSearched] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    const found = MOCK_SHIPMENTS.find(s => s.trackingNumber.toUpperCase() === trackingId.toUpperCase());
    if (found) {
      setResult(found);
      setError("");
    } else {
      setResult(null);
      setError("Tracking number not found. Please check and try again.");
    }
  };

  return (
    <div className={`w-full ${compact ? '' : 'max-w-4xl mx-auto'}`}>
      <Card className={`${compact ? 'bg-white/95 backdrop-blur shadow-2xl border-t-4 border-t-secondary' : 'bg-background shadow-lg'}`}>
        <CardHeader className={compact ? 'pb-2' : ''}>
          <CardTitle className="font-heading uppercase text-primary flex items-center gap-2">
            <Search className="h-5 w-5 text-secondary" />
            Track Your Shipment
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleTrack} className={`flex gap-2 ${compact ? 'flex-col' : 'flex-col md:flex-row'}`}>
            <Input 
              placeholder="Enter Tracking Number (e.g. UPS123456789)" 
              value={trackingId}
              onChange={(e) => setTrackingId(e.target.value)}
              className="font-mono uppercase text-lg border-primary/20 focus-visible:ring-secondary"
            />
            <Button type="submit" size={compact ? 'default' : 'lg'} className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold uppercase tracking-wide">
              Track
            </Button>
          </form>

          <AnimatePresence>
            {searched && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-6 overflow-hidden"
              >
                {error && (
                  <div className="p-4 bg-red-50 text-red-700 border border-red-200 rounded-md flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5" />
                    {error}
                  </div>
                )}

                {result && (
                  <div className="space-y-6">
                    <div className="flex flex-wrap gap-4 justify-between items-start bg-muted p-4 rounded-lg border">
                      <div>
                        <p className="text-sm text-muted-foreground uppercase tracking-wider font-bold">Status</p>
                        <p className={`text-2xl font-heading font-bold ${result.status === 'Delivered' ? 'text-green-600' : result.status === 'Exception' ? 'text-red-600' : 'text-primary'}`}>
                          {result.status}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground uppercase tracking-wider font-bold">Estimated Delivery</p>
                        <p className="text-lg font-medium">{result.estimatedDelivery}</p>
                      </div>
                       <div>
                        <p className="text-sm text-muted-foreground uppercase tracking-wider font-bold">Service</p>
                        <p className="text-lg font-medium">{result.service}</p>
                      </div>
                    </div>

                    <div className="relative border-l-2 border-muted ml-3 space-y-8 pb-4">
                      {result.events.map((event, index) => (
                        <div key={index} className="relative pl-8">
                          <div className={`absolute -left-[9px] top-1 h-4 w-4 rounded-full border-2 ${index === 0 ? 'bg-secondary border-secondary' : 'bg-background border-muted-foreground'}`}></div>
                          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1">
                            <div>
                              <p className={`font-bold ${index === 0 ? 'text-foreground' : 'text-muted-foreground'}`}>{event.status}</p>
                              <p className="text-sm text-muted-foreground">{event.location}</p>
                            </div>
                            <p className="text-sm font-mono text-muted-foreground">{event.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </div>
  );
}
