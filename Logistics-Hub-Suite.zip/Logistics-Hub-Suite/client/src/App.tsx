import { Switch, Route } from "wouter";
import { Layout } from "./components/layout";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Tracking from "./pages/Tracking";
import Quote from "./pages/Quote";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Admin from "./pages/Admin";
import LocationsPage from "./pages/Locations";
import Readme from "./pages/Readme";
import NotFound from "./pages/not-found";
import { Toaster } from "@/components/ui/toaster";

function App() {
  return (
    <>
      <Layout>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/services" component={Services} />
          <Route path="/tracking" component={Tracking} />
          <Route path="/quote" component={Quote} />
          <Route path="/locations" component={LocationsPage} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/login" component={Login} />
          <Route path="/admin" component={Admin} />
          <Route path="/readme" component={Readme} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
      <Toaster />
    </>
  );
}

export default App;
